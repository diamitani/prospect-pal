const cfg = PAE.cfg();
return [{ json: { signal_brief: {
  icp: cfg.icp,
  target_titles: PAE.list(cfg.target_titles, 12),
  signals: PAE.list(cfg.signals, 25),
  product_summary: cfg.product_summary,
  value_prop: cfg.value_prop
} } }];
