// Validates the Config node (plus optional webhook overrides) and produces ONE clean config object.
const KEYS = ['start_mode','icp','target_titles','signals','signals_source','signals_url','companies_source','companies_url','companies_json','contacts_source','contacts_url','contacts_per_company','email_pattern','leads_json','dns_resolver_url','research_source','research_url','min_confidence','company_name','product_summary','value_prop','tone','sender_first_name','signature','email_mode','max_words','allow_links','outreach_mode','mailbox_from','sequence_api_url','dry_run','allow_guessed_sends','allow_webhook_live_send','allow_private_urls','max_leads','max_sends_per_run','throttle_seconds','callback_url'];
const OVERRIDABLE = new Set(['start_mode','icp','target_titles','signals','companies_json','leads_json','contacts_source','research_source','email_mode','max_leads','min_confidence','max_words','tone','value_prop','product_summary','company_name','sender_first_name','signature','dry_run','callback_url']);
const ENUM = {
  start_mode: ['from_icp', 'have_leads'],
  signals_source: ['icp_only', 'http'],
  companies_source: ['inline', 'http'],
  contacts_source: ['provided', 'provider_http', 'guess_syntax'],
  email_pattern: ['first.last', 'flast', 'first', 'firstlast', 'first_last', 'f.last'],
  research_source: ['llm_only', 'http_search'],
  email_mode: ['body_only', 'full_email'],
  outreach_mode: ['log_only', 'mailbox', 'sequence_api']
};
const base = $input.first().json || {};
const viaWebhook = base.headers !== undefined && base.body !== undefined;
// A bad webhook call gets an HTTP 400 with the reason. A bad manual run stops with the error shown on this node.
function run() {
const body = (viaWebhook && base.body && typeof base.body === 'object' && !Array.isArray(base.body)) ? base.body : {};
const cfg = {};
for (const k of KEYS) cfg[k] = base[k];
const warnings = [];
if (viaWebhook) {
  for (const k of Object.keys(body)) {
    if (!OVERRIDABLE.has(k)) { warnings.push('ignored_override:' + k); continue; }
    cfg[k] = body[k];
  }
  if ('dry_run' in body) {
    cfg.dry_run = body.dry_run;
    if (body.dry_run === false && base.allow_webhook_live_send !== true) { cfg.dry_run = true; warnings.push('webhook_cannot_turn_dry_run_off'); }
  }
}
const str = (v, max) => (v === undefined || v === null ? '' : String(v)).trim().slice(0, max);
for (const k of Object.keys(ENUM)) {
  const v = str(cfg[k], 40);
  if (!ENUM[k].includes(v)) throw new Error('Config "' + k + '" must be one of: ' + ENUM[k].join(', ') + ' (got "' + v + '")');
  cfg[k] = v;
}
const parseRows = (v, label) => {
  if (v === undefined || v === null || v === '') return [];
  let a = v;
  if (typeof v === 'string') { try { a = JSON.parse(v); } catch (e) { throw new Error(label + ' is not valid JSON: ' + e.message); } }
  if (!Array.isArray(a)) throw new Error(label + ' must be a JSON array');
  if (a.length > 500) throw new Error(label + ' has more than 500 rows');
  return a.filter(x => x && typeof x === 'object' && !Array.isArray(x));
};
cfg.companies = parseRows(cfg.companies_json, 'companies_json');
cfg.leads = parseRows(cfg.leads_json, 'leads_json');
delete cfg.companies_json; delete cfg.leads_json;
cfg.icp = str(cfg.icp, 2000);
cfg.target_titles = str(Array.isArray(cfg.target_titles) ? cfg.target_titles.join('; ') : cfg.target_titles, 600);
cfg.signals = str(Array.isArray(cfg.signals) ? cfg.signals.join('\n') : cfg.signals, 3000);
for (const k of ['company_name','sender_first_name']) cfg[k] = str(cfg[k], 120);
for (const k of ['product_summary','value_prop','tone']) cfg[k] = str(cfg[k], 1500);
cfg.signature = str(cfg.signature, 400);
cfg.max_leads = Math.round(PAE.num(cfg.max_leads, 1, 100, 10));
cfg.contacts_per_company = Math.round(PAE.num(cfg.contacts_per_company, 1, 5, 2));
cfg.max_sends_per_run = Math.round(PAE.num(cfg.max_sends_per_run, 0, 200, 25));
cfg.throttle_seconds = Math.round(PAE.num(cfg.throttle_seconds, 0, 600, 30));
cfg.max_words = Math.round(PAE.num(cfg.max_words, 40, 250, 120));
cfg.min_confidence = PAE.num(cfg.min_confidence, 0, 1, 0.6);
cfg.signals = cfg.signals || '';
for (const k of ['allow_links','dry_run','allow_guessed_sends','allow_webhook_live_send','allow_private_urls']) cfg[k] = PAE.bool(cfg[k], k === 'dry_run');
cfg.allow_private_urls = base.allow_private_urls === true;
const privOk = cfg.allow_private_urls;
for (const k of ['signals_url','companies_url','contacts_url','research_url','sequence_api_url','dns_resolver_url']) cfg[k] = PAE.httpsUrl(cfg[k], privOk);
cfg.callback_url = PAE.httpsUrl(cfg.callback_url, (viaWebhook && 'callback_url' in body) ? false : privOk);
cfg.mailbox_from = str(cfg.mailbox_from, 254);
if (cfg.outreach_mode === 'mailbox' && !PAE.validEmail(cfg.mailbox_from)) throw new Error('outreach_mode "mailbox" needs a valid mailbox_from address');
if (cfg.outreach_mode === 'sequence_api' && !cfg.sequence_api_url) throw new Error('outreach_mode "sequence_api" needs sequence_api_url');
const mustFill = ['company_name', 'product_summary', 'value_prop', 'sender_first_name', 'signature'].concat(cfg.start_mode === 'from_icp' ? ['icp', 'target_titles'] : []);
for (const k of mustFill) if (/REPLACE ME/i.test(cfg[k])) throw new Error('Config "' + k + '" still has the REPLACE ME placeholder. Edit the Config node first.');
if (!cfg.product_summary || !cfg.value_prop) throw new Error('Fill in product_summary and value_prop in the Config node. The research and email steps cannot be written without them.');
if (cfg.start_mode === 'from_icp') {
  if (!cfg.icp) throw new Error('start_mode "from_icp" needs an icp description');
  if (cfg.companies_source === 'inline' && !cfg.companies.length) throw new Error('companies_source "inline" needs at least one company in companies_json');
  if (cfg.companies_source === 'http' && !cfg.companies_url) throw new Error('companies_source "http" needs companies_url');
  if (cfg.signals_source === 'http' && !cfg.signals_url) throw new Error('signals_source "http" needs signals_url');
  if (cfg.contacts_source === 'provider_http' && !cfg.contacts_url) throw new Error('contacts_source "provider_http" needs contacts_url');
  if (cfg.contacts_source === 'guess_syntax' && !cfg.dns_resolver_url) throw new Error('contacts_source "guess_syntax" needs dns_resolver_url');
} else if (!cfg.leads.length) {
  throw new Error('start_mode "have_leads" needs at least one row in leads_json');
}
if (cfg.research_source === 'http_search' && !cfg.research_url) throw new Error('research_source "http_search" needs research_url');
const rid = 'pae-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
return [{ json: { valid: true, cfg, warnings, run_id: rid, started_at: new Date().toISOString(), via_webhook: viaWebhook } }];
}
try { return run(); } catch (e) {
  if (!viaWebhook) throw e;
  return [{ json: { valid: false, via_webhook: true, error_message: PAE.errText(e) } }];
}
