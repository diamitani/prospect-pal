// One tidy row per lead. This is what you read after a run.
const cfg = PAE.cfg();
const v = $('Validate Config').first(0, 0).json;
const order = (a, b) => (parseInt(String(a.lead.id).replace(/\D/g, ''), 10) || 0) - (parseInt(String(b.lead.id).replace(/\D/g, ''), 10) || 0);
const items = $input.all().map(i => i.json).filter(j => j && j.lead).sort(order);
return items.map(({ lead }) => ({ json: {
  run_id: v.run_id, lead_id: lead.id, status: lead.status, reason: lead.reason || '',
  company: lead.company.name, domain: lead.company.domain || '', fit_score: lead.company.fit_score === undefined ? null : lead.company.fit_score,
  first_name: lead.person ? lead.person.first_name : '', last_name: lead.person ? lead.person.last_name : '', title: lead.person ? lead.person.title : '',
  email: lead.person ? lead.person.email : '', email_source: lead.email_source, email_confidence: lead.email_confidence,
  subject: lead.email ? lead.email.subject : '', body: lead.email ? lead.email.body : '',
  hook: lead.research && lead.research.hooks[0] ? lead.research.hooks[0].fact : '',
  hook_quote: lead.research && lead.research.hooks[0] ? lead.research.hooks[0].evidence_quote : '',
  hooks_dropped: lead.research ? lead.research.dropped_unverified : 0,
  qa_flags: lead.email ? lead.email.qa_flags : []
} }));
