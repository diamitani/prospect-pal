// Merges signals fetched over HTTP (if any) into the brief. Safe when the HTTP step was skipped.
const brief = $('1a. Signals: Brief').first().json.signal_brief;
const items = $input.all();
const first = items.length ? (items[0].json || {}) : {};
const grab = (v) => {
  if (typeof v === 'string') return [v];
  if (Array.isArray(v)) return v.flatMap(grab);
  if (v && typeof v === 'object') {
    for (const k of ['signal', 'text', 'title', 'name', 'description']) if (typeof v[k] === 'string') return [v[k]];
    for (const k of ['signals', 'items', 'data', 'results']) if (Array.isArray(v[k])) return grab(v[k]);
  }
  return [];
};
let extra = [];
if (!first.signal_brief && !first.error) extra = items.flatMap(i => grab(i.json));
const merged = PAE.uniq([...brief.signals, ...extra.map(s => PAE.strip(s).slice(0, 200)).filter(Boolean)]).slice(0, 25);
return [{ json: { signal_brief: { ...brief, signals: merged }, fetched_signal_count: extra.length, signals_fetch_error: first.error ? PAE.errText(first.error) : '' } }];
