// "Already have leads" path: your own list goes straight to research. Steps 1 and 2 are skipped.
const cfg = PAE.cfg();
const T = (v, n) => String(v == null ? '' : v).trim().slice(0, n);
const out = [];
for (const r of cfg.leads) {
  const domain = PAE.domain(r.domain || r.website || r.company_domain || '');
  const name = T(r.company || r.company_name || r.organization || domain, 160);
  const person = { first_name: T(r.first_name || r.firstName, 60), last_name: T(r.last_name || r.lastName, 60), title: T(r.title || r.job_title, 120), email: T(r.email || r.work_email, 254).toLowerCase(), linkedin_url: T(r.linkedin_url || r.linkedin, 300) };
  const company = { name, domain, industry: T(r.industry, 120), size: T(r.size || r.employees, 60), notes: PAE.strip(r.notes || r.signal || '').slice(0, 1500) };
  let status = 'ready', reason = '';
  if (!name) { status = 'skipped_no_contact'; reason = 'row has no company'; }
  else if (!PAE.validEmail(person.email)) { status = 'skipped_no_email'; reason = 'row has no valid email'; }
  else if (!person.first_name) { status = 'skipped_no_name'; reason = 'first name is missing'; }
  const noEmail = status === 'skipped_no_email';
  out.push({ json: { lead: { company, person, email_source: noEmail ? 'none' : 'lead_list', email_confidence: noEmail ? 'none' : 'provided', status, reason } } });
}
return out;
