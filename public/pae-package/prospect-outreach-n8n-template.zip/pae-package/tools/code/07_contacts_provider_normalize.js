// Normalizes the response of your contact data tool (Clay, ZoomInfo, Apollo, a proxy of your own...) into leads.
const cfg = PAE.cfg();
const src = $('3b. Contacts: Provider Input').all();
const T = (v, n) => String(v == null ? '' : v).trim().slice(0, n);
const out = [];
const produced = new Map();
const errors = new Map();
for (const it of $input.all()) {
  const idx = (it.pairedItem && it.pairedItem.item !== undefined) ? it.pairedItem.item : 0;
  const { people: _p, ...company } = (src[idx] || src[0]).json.company;
  const j = it.json || {};
  if (j.error) { errors.set(idx, PAE.errText(j.error)); continue; }
  let rows = Array.isArray(j) ? j : (['contacts', 'people', 'results', 'data', 'items'].map(k => j[k]).find(Array.isArray) || null);
  if (!rows) rows = [j];
  for (const r of rows) {
    if (!r || typeof r !== 'object') continue;
    if ((produced.get(idx) || 0) >= cfg.contacts_per_company) break;
    const full = T(r.name || r.full_name, 120).split(/\s+/);
    const person = {
      first_name: T(r.first_name || r.firstName || (full.length > 1 ? full[0] : ''), 60),
      last_name: T(r.last_name || r.lastName || (full.length > 1 ? full.slice(1).join(' ') : ''), 60),
      title: T(r.title || r.job_title || r.jobTitle, 120),
      email: T(r.email || r.work_email || r.business_email, 254).toLowerCase(),
      linkedin_url: T(r.linkedin_url || r.linkedin || r.linkedinUrl, 300)
    };
    if (!person.first_name && !person.email) continue;
    produced.set(idx, (produced.get(idx) || 0) + 1);
    if (!PAE.validEmail(person.email)) { out.push({ json: { lead: { company, person, email_source: 'none', email_confidence: 'none', status: 'skipped_no_email', reason: 'provider returned the person without a valid email' } } }); continue; }
    out.push({ json: { lead: { company, person, email_source: 'provider', email_confidence: 'provider', status: person.first_name ? 'ready' : 'skipped_no_name', reason: '' } } });
  }
}
src.forEach((s, idx) => {
  if (!produced.has(idx)) {
    const { people: _p, ...company } = s.json.company;
    out.push({ json: { lead: { company, person: null, email_source: 'none', email_confidence: 'none', status: 'skipped_no_contact', reason: errors.has(idx) ? 'contact provider error: ' + errors.get(idx) : 'contact provider returned nobody for this company' } } });
  }
});
return out;
