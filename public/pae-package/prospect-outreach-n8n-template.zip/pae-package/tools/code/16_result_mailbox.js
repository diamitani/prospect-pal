const lead = JSON.parse(JSON.stringify($('8b. Action?').item.json.lead));
const j = $input.item.json || {};
const accepted = Array.isArray(j.accepted) && j.accepted.length > 0;
if (j.error) { lead.status = 'send_failed'; lead.reason = 'mailbox error: ' + PAE.errText(j.error); }
else if (j.messageId || accepted) { lead.status = 'sent'; lead.reason = ''; lead.message_id = String(j.messageId || '').slice(0, 200); }
else { lead.status = 'send_unconfirmed'; lead.reason = 'the send step returned no confirmation. Is the "8d. Send Email (SMTP)" node enabled and its credential set?'; }
return { json: { lead } };
