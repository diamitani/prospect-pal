// Turns whatever the company source returned into clean {company} items. Dedupes by domain/name and caps the list.
const cfg = PAE.cfg();
const WRAP = ['items', 'data', 'companies', 'results', 'records'];
const rows = [];
let firstError = '';
for (const it of $input.all()) {
  const j = it.json || {};
  if (j.error) { firstError = firstError || PAE.errText(j.error); continue; }
  const r = j.raw !== undefined ? j.raw : j;
  if (r && typeof r === 'object' && j.raw === undefined && !r.name && !r.company && !r.company_name && !r.domain && !r.website) {
    const k = WRAP.find(w => Array.isArray(r[w]));
    if (k) { rows.push(...r[k]); continue; }
  }
  rows.push(r);
}
if (!rows.length && firstError) throw new Error('Company source failed: ' + firstError);
const seen = new Set();
const out = [];
for (const r of rows) {
  if (!r || typeof r !== 'object') continue;
  const name = String(r.name || r.company || r.company_name || '').trim().slice(0, 160);
  const domain = PAE.domain(r.domain || r.website || r.url || '');
  if (!name && !domain) continue;
  const key = domain || name.toLowerCase();
  if (seen.has(key)) continue;
  seen.add(key);
  const people = (Array.isArray(r.people) ? r.people : (Array.isArray(r.contacts) ? r.contacts : [])).filter(p => p && typeof p === 'object').slice(0, 10);
  out.push({ json: { company: {
    name: name || domain, domain,
    industry: String(r.industry || '').slice(0, 120),
    size: String(r.size || r.employees || '').slice(0, 60),
    notes: PAE.strip(r.notes || r.signal || r.description || '').slice(0, 1500),
    people } } });
  if (out.length >= cfg.max_leads) break;
}
if (!out.length) throw new Error('No usable companies found. Each company needs at least a name or a domain.');
return out;
