// Per lead: deterministic checks on the written email. A model never grades its own work here.
const cfg = PAE.cfg();
const lead = JSON.parse(JSON.stringify($('7a. Hooks OK?').item.json.lead));
const out = $input.item.json || {};
if (out.error || !out.output || typeof out.output !== 'object') {
  lead.status = 'email_failed'; lead.reason = 'email step failed: ' + PAE.errText(out.error || 'no structured output');
  return { json: { lead } };
}
const flags = [];
let subject = String(out.output.subject || '').replace(/[\r\n]+/g, ' ').trim();
let text = String(out.output.body || '').replace(/\r/g, '').trim();
const p = lead.person;
if (cfg.email_mode === 'body_only') text = 'Hi ' + p.first_name + ',\n\n' + text;
const words = text.split(/\s+/).filter(Boolean).length;
if (subject.length < 3 || subject.length > 80) flags.push('subject_length');
if (/^(re|fwd?):/i.test(subject)) flags.push('fake_thread_subject');
if (subject.length > 6 && subject === subject.toUpperCase()) flags.push('subject_all_caps');
if (/!/.test(subject + text)) flags.push('exclamation_mark');
if (words > cfg.max_words) flags.push('too_long:' + words + '_words');
if (words < 20) flags.push('too_short');
if (!cfg.allow_links && /(https?:\/\/|www\.)/i.test(text)) flags.push('link_not_allowed');
if (/\{\{|\}\}|\[[A-Za-z ]{2,30}\]|<[a-z\/][^>]*>/.test(subject + text)) flags.push('placeholder_left_in_text');
const banned = ['hope this email finds you', 'hope you are doing well', "hope you're doing well", 'touch base', 'circle back', 'synergy', 'game-changer', 'game changer', 'revolutionary', 'cutting-edge', 'cutting edge', 'pick your brain', 'just following up', 'i came across your profile'];
const low = (subject + ' ' + text).toLowerCase();
for (const b of banned) if (low.includes(b)) flags.push('banned_phrase:' + b);
const allowed = PAE.nrm([lead.research.hooks.map(h => h.fact + ' ' + h.relevance).join(' '), cfg.product_summary, cfg.value_prop, lead.company.notes, p.first_name, lead.company.name].join(' '));
const nums = (text.match(/\d[\d,.]*%?/g) || []).map(n => PAE.nrm(n)).filter(Boolean);
for (const n of PAE.uniq(nums)) if (!allowed.includes(n)) { flags.push('unverified_number:' + n); break; }
const used = Number(out.output.hook_used);
if (!(used >= 1 && used <= lead.research.hooks.length)) flags.push('hook_used_invalid');
const live = !cfg.dry_run && cfg.outreach_mode !== 'log_only';
if (live && !/unsubscribe|opt[- ]?out|reply stop|remove you/i.test(cfg.signature)) flags.push('signature_missing_opt_out');
const body = text + (cfg.signature ? '\n\n' + cfg.signature : '');
lead.email = { to: p.email, subject, body, words, hook_used: used, qa_flags: flags };
lead.status = flags.length ? 'needs_review' : 'ready';
lead.reason = flags.length ? 'email_qa: ' + flags.join(', ') : '';
return { json: { lead } };
