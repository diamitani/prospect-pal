// ===== PAE shared helpers (the generator pastes this block into each Code node that needs it) =====
const PAE = {
  isPrivateHost(h) {
    h = String(h || '').toLowerCase().replace(/^\[|\]$/g, '');
    if (!h) return true;
    if (h === 'localhost' || /\.(localhost|local|internal|lan|home\.arpa)$/.test(h)) return true;
    if (/^\d+$/.test(h) || /^0x[0-9a-f]+$/i.test(h)) return true;
    const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
    if (m) {
      const a = +m[1], b = +m[2];
      if (a === 0 || a === 10 || a === 127 || a >= 224) return true;
      if (a === 169 && b === 254) return true;
      if (a === 172 && b >= 16 && b <= 31) return true;
      if (a === 192 && b === 168) return true;
      if (a === 100 && b >= 64 && b <= 127) return true;
      return false;
    }
    if (h.includes(':')) return h === '::1' || h === '::' || /^f[cd]/.test(h) || /^fe[89ab]/.test(h) || h.startsWith('::ffff:');
    if (!h.includes('.')) return true;
    return false;
  },
  httpsUrl(u, allowPrivate) {
    const s = String(u || '').trim();
    if (!s) return '';
    const m = s.match(/^(https?):\/\/([^\/?#]*)([\/?#][^]*)?$/i);
    if (!m) throw new Error('Not a valid URL: ' + s.slice(0, 80));
    const scheme = m[1].toLowerCase();
    const authority = m[2];
    if (!(scheme === 'https' || (allowPrivate && scheme === 'http'))) throw new Error('URL must start with https:// : ' + s.slice(0, 80));
    if (authority.includes('@')) throw new Error('URL must not contain a username or password');
    if (/\s/.test(s)) throw new Error('URL must not contain spaces');
    let host = authority;
    if (host.startsWith('[')) host = host.slice(0, host.indexOf(']') + 1);
    else host = host.replace(/:\d*$/, '');
    if (!host) throw new Error('URL has no host');
    if (!allowPrivate && PAE.isPrivateHost(host)) throw new Error('URL host is private or not allowed: ' + host);
    return s;
  },
  list(v, max) {
    const a = Array.isArray(v) ? v : String(v == null ? '' : v).split(/[\n;|]+/);
    return a.map(x => String(x).trim()).filter(Boolean).slice(0, max || 50);
  },
  uniq(a) { return Array.from(new Set(a)); },
  domain(v) {
    const s = String(v || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split(/[\/?#]/)[0];
    return /^[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}$/.test(s) ? s : '';
  },
  strip(s) {
    return String(s == null ? '' : s).replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  },
  num(v, lo, hi, d) { const n = Number(v); return isFinite(n) && v !== '' && v !== null ? Math.min(hi, Math.max(lo, n)) : d; },
  bool(v, d) { return v === true || v === 'true' ? true : (v === false || v === 'false' ? false : d); },
  validEmail(e) { const s = String(e || '').trim(); return s.length <= 254 && /^[^\s@<>()\[\],;:"]+@[a-z0-9-]+(\.[a-z0-9-]+)+$/i.test(s); },
  ascii(s) { return String(s || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z]/g, ''); },
  errText(e) { return String((e && (e.message || e.description)) || e || '').slice(0, 200); },
  cfg() { return $('Validate Config').first(0, 0).json.cfg; },
  nrm(s) { return String(s == null ? '' : s).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
};
// ===== end helpers =====
