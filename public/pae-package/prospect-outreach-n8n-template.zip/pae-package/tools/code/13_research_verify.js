// Per lead: keeps only hooks whose quote really appears in the evidence. Then writes the email brief.
const cfg = PAE.cfg();
const prep = $('6c. Research: Prepare').item.json;
const lead = JSON.parse(JSON.stringify(prep.lead));
const out = $input.item.json || {};
if (out.error || !out.output || typeof out.output !== 'object') {
  lead.status = 'research_failed'; lead.reason = 'research step failed: ' + PAE.errText(out.error || 'no structured output');
  return { json: { lead } };
}
const ev = PAE.nrm(prep.evidence_text);
const hooks = [];
let dropped = 0;
for (const h of (Array.isArray(out.output.hooks) ? out.output.hooks : []).slice(0, 5)) {
  const fact = PAE.strip(h && h.fact).slice(0, 240);
  const quote = PAE.nrm(h && h.evidence_quote);
  const conf = PAE.num(h && h.confidence, 0, 1, 0);
  if (fact && quote.length >= 12 && ev.includes(quote) && conf >= cfg.min_confidence) {
    hooks.push({ fact, evidence_quote: String(h.evidence_quote).slice(0, 200), relevance: PAE.strip(h.relevance).slice(0, 200), confidence: conf });
  } else dropped++;
}
hooks.sort((a, b) => b.confidence - a.confidence);
lead.research = { hooks: hooks.slice(0, 3), dropped_unverified: dropped };
if (!hooks.length) {
  lead.status = 'needs_review';
  lead.reason = 'no_verified_hook' + (dropped ? ' (' + dropped + ' hook(s) dropped: quote not found in the evidence)' : '');
  return { json: { lead } };
}
const p = lead.person;
const email_prompt = [
  'Write a first-touch sales email.',
  'RECIPIENT: ' + p.first_name + (p.title ? ', ' + p.title : '') + ' at ' + lead.company.name,
  'WHAT WE SELL: ' + cfg.product_summary,
  'OUR VALUE: ' + cfg.value_prop,
  'TONE: ' + (cfg.tone || 'plain, respectful, direct'),
  'MODE: ' + (cfg.email_mode === 'body_only' ? 'body_only. Write only the body paragraphs. No greeting, no sign-off, no signature.' : 'full_email. Include a greeting line using the first name. No signature.'),
  'MAX WORDS: ' + cfg.max_words,
  'LINKS: ' + (cfg.allow_links ? 'allowed but not needed' : 'do not include any link or web address'),
  '',
  'VERIFIED HOOKS (the only facts you may use about the recipient or their company):',
  ...hooks.slice(0, 3).map((h, i) => (i + 1) + '. ' + h.fact + ' (why it matters: ' + h.relevance + ')'),
  '',
  'Rules: open with one hook as a plain fact, not flattery. Use only one hook. Make one clear, low-pressure ask. Do not claim results, customers, numbers or familiarity that are not in the text above. No emojis. No exclamation marks. Report in hook_used which numbered hook you used.'
].join('\n');
return { json: { lead, email_prompt } };
