// Companies that already carry their people (and emails) in the data you supplied.
const cfg = PAE.cfg();
const out = [];
const T = (v, n) => String(v == null ? '' : v).trim().slice(0, n);
for (const it of $input.all()) {
  const { people, ...company } = it.json.company;
  let n = 0;
  for (const p of (people || [])) {
    if (n >= cfg.contacts_per_company) break;
    n++;
    const person = { first_name: T(p.first_name || p.firstName, 60), last_name: T(p.last_name || p.lastName, 60), title: T(p.title || p.job_title, 120), email: T(p.email || p.work_email, 254).toLowerCase(), linkedin_url: T(p.linkedin_url || p.linkedin, 300) };
    if (!PAE.validEmail(person.email)) { out.push({ json: { lead: { company, person, email_source: 'none', email_confidence: 'none', status: 'skipped_no_email', reason: 'person has no valid email in the data you provided' } } }); continue; }
    if (!person.first_name) { out.push({ json: { lead: { company, person, email_source: 'provided', email_confidence: 'provided', status: 'skipped_no_name', reason: 'first name is missing' } } }); continue; }
    out.push({ json: { lead: { company, person, email_source: 'provided', email_confidence: 'provided', status: 'ready', reason: '' } } });
  }
  if (!people || !people.length) out.push({ json: { lead: { company, person: null, email_source: 'none', email_confidence: 'none', status: 'skipped_no_contact', reason: 'no people provided for this company' } } });
}
return out;
