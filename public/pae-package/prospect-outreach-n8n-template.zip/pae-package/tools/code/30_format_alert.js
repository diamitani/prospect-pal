// Builds a short alert. It never includes lead data, only where the run failed and why.
const j = $input.first().json || {};
const ex = j.execution || {};
const wf = j.workflow || {};
const err = ex.error || {};
// n8n can cut err.message at the first colon, so prefer the first line of the stack, which holds the full text.
const stackLine = String(err.stack || '').split('\n')[0].replace(/^[A-Za-z]*Error:\s*/, '');
const errText = stackLine || String(err.message || 'unknown');
const lines = [
  'PAE run failed',
  'Workflow: ' + String(wf.name || 'unknown').slice(0, 120),
  'Failed at node: ' + String(err.node && err.node.name || ex.lastNodeExecuted || 'unknown').slice(0, 120),
  'Error: ' + errText.replace(/\s+/g, ' ').slice(0, 300),
  'Execution id: ' + String(ex.id || 'n/a').slice(0, 40)
];
let url = '';
const raw = String(j.alert_webhook_url || '').trim();
if (raw) {
  try {
    url = PAE.httpsUrl(raw, j.allow_private_urls === true);
  } catch (e) {
    lines.push('(alert_webhook_url was rejected: ' + PAE.errText(e) + ')');
  }
}
return [{ json: { text: lines.join('\n'), alert_url: url } }];
