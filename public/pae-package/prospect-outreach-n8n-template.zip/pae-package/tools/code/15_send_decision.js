// Per lead: decides what happens to a clean draft. Default is: nothing is sent.
const cfg = PAE.cfg();
const lead = JSON.parse(JSON.stringify($input.item.json.lead));
let action = 'draft_only';
let why = '';
if (cfg.outreach_mode === 'log_only') why = 'outreach_mode is log_only';
else if (cfg.dry_run) why = 'dry_run is on, nothing was sent';
else if (!lead.send_slot) why = 'over max_sends_per_run';
else if (lead.email_source === 'guessed' && !cfg.allow_guessed_sends) why = 'email address is a guess; sending to guesses is blocked (allow_guessed_sends is off)';
else if (cfg.outreach_mode === 'mailbox') action = 'mailbox';
else if (cfg.outreach_mode === 'sequence_api') action = 'sequence';
lead.status = action === 'draft_only' ? 'drafted' : 'sending';
lead.reason = why;
return { json: { lead, action } };
