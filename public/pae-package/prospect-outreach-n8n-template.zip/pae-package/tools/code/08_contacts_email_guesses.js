// Builds an email guess per person from their name, the company domain and your chosen pattern. Nothing is sent here.
const cfg = PAE.cfg();
const PATTERNS = {
  'first.last': (f, l) => f + '.' + l, 'flast': (f, l) => f[0] + l, 'first': (f) => f,
  'firstlast': (f, l) => f + l, 'first_last': (f, l) => f + '_' + l, 'f.last': (f, l) => f[0] + '.' + l
};
const T = (v, n) => String(v == null ? '' : v).trim().slice(0, n);
const out = [];
for (const it of $input.all()) {
  const { people, ...company } = it.json.company;
  let n = 0;
  for (const p of (people || [])) {
    if (n >= cfg.contacts_per_company) break;
    n++;
    const first_name = T(p.first_name || p.firstName, 60), last_name = T(p.last_name || p.lastName, 60);
    const person = { first_name, last_name, title: T(p.title || p.job_title, 120), email: '', linkedin_url: T(p.linkedin_url || p.linkedin, 300) };
    const given = T(p.email || p.work_email, 254).toLowerCase();
    const mx_name = company.domain || 'invalid.invalid';
    let lead;
    if (PAE.validEmail(given)) {
      lead = { company, person: { ...person, email: given }, email_source: 'provided', email_confidence: 'provided', status: 'ready', reason: '' };
    } else {
      const f = PAE.ascii(first_name), l = PAE.ascii(last_name);
      if (!company.domain) lead = { company, person, email_source: 'none', email_confidence: 'none', status: 'skipped_no_domain', reason: 'company domain is needed to guess an email' };
      else if (!f || !l) lead = { company, person, email_source: 'none', email_confidence: 'none', status: 'skipped_no_name', reason: 'first and last name are needed to guess an email' };
      else lead = { company, person: { ...person, email: PATTERNS[cfg.email_pattern](f, l) + '@' + company.domain }, email_source: 'guessed', email_confidence: 'guessed_unverified', status: 'ready', reason: '' };
    }
    out.push({ json: { lead, mx_name } });
  }
  if (!people || !people.length) out.push({ json: { lead: { company, person: null, email_source: 'none', email_confidence: 'none', status: 'skipped_no_contact', reason: 'no people provided for this company' }, mx_name: company.domain || 'invalid.invalid' } });
}
return out;
