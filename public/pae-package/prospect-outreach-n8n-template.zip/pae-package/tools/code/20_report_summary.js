const v = $('Validate Config').first(0, 0).json;
const cfg = v.cfg;
const rows = $input.all().map(i => i.json);
const counts = {};
for (const r of rows) counts[r.status] = (counts[r.status] || 0) + 1;
const conf = {};
for (const r of rows) if (r.email) conf[r.email_confidence] = (conf[r.email_confidence] || 0) + 1;
return [{ json: {
  run_id: v.run_id, started_at: v.started_at, finished_at: new Date().toISOString(),
  dry_run: cfg.dry_run, outreach_mode: cfg.outreach_mode, warnings: v.warnings,
  total_rows: rows.length, by_status: counts, by_email_confidence: conf,
  nothing_was_sent: !rows.some(r => ['sent', 'queued'].includes(r.status)),
  rows
} }];
