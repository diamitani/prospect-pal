// Single exit for every contact path: dedupe, assign ids, cap the number of leads that continue.
const cfg = PAE.cfg();
let signals = [];
try { signals = $('1c. Signals: Finalize').first(0, 0).json.signal_brief.signals || []; } catch (e) { signals = []; }
const seen = new Set();
const out = [];
let ready = 0, n = 0;
for (const it of $input.all()) {
  const lead = it.json.lead;
  if (!lead) continue;
  const p = lead.person;
  const key = (p && p.email) ? p.email.toLowerCase() : ((lead.company.domain || lead.company.name) + '|' + (p ? (p.first_name + p.last_name).toLowerCase() : ''));
  if (seen.has(key)) continue;
  seen.add(key);
  if (lead.status === 'ready') {
    if (ready >= cfg.max_leads) { lead.status = 'skipped_over_cap'; lead.reason = 'max_leads reached for this run'; } else ready++;
  }
  lead.id = 'lead_' + (++n);
  lead.signals = signals.slice(0, 10);
  lead.send_slot = lead.status === 'ready' && ready <= cfg.max_sends_per_run;
  out.push({ json: { lead } });
}
return out;
