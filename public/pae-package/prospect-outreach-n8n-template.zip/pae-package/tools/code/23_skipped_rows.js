return $input.all().map(i => {
  const { people, ...company } = i.json.company;
  return { json: { lead: { company, person: null, email_source: 'none', email_confidence: 'none', status: company.fit_status || 'skipped_low_fit', reason: company.fit_reason || 'low fit' } } };
});
