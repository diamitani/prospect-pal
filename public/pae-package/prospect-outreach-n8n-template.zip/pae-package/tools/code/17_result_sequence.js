const lead = JSON.parse(JSON.stringify($('8b. Action?').item.json.lead));
const j = $input.item.json || {};
const code = Number(j.statusCode);
if (j.error) { lead.status = 'send_failed'; lead.reason = 'sequence tool error: ' + PAE.errText(j.error); }
else if (code >= 200 && code < 300) { lead.status = 'queued'; lead.reason = ''; }
else { lead.status = 'send_failed'; lead.reason = 'sequence tool answered HTTP ' + (isFinite(code) ? code : 'unknown'); }
return { json: { lead } };
