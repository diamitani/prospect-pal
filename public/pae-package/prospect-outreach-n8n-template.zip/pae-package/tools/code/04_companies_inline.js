const cfg = PAE.cfg();
return cfg.companies.map(c => ({ json: { raw: c } }));
