// Reads the DNS answer for each lead's domain. MX proves a domain accepts mail. It does NOT prove the mailbox exists.
const src = $('3d. Contacts: Email Guesses').all();
const out = [];
for (const it of $input.all()) {
  const idx = (it.pairedItem && it.pairedItem.item !== undefined) ? it.pairedItem.item : 0;
  const lead = JSON.parse(JSON.stringify((src[idx] || src[0]).json.lead));
  if (lead.status !== 'ready') { out.push({ json: { lead } }); continue; }
  const j = it.json || {};
  if (j.error || j.Status === undefined) {
    lead.status = 'needs_review'; lead.reason = 'mx_lookup_failed: ' + (j.error ? PAE.errText(j.error) : 'unexpected DNS response');
  } else if (j.Status === 3) {
    lead.status = 'skipped_no_route'; lead.reason = 'domain does not exist (NXDOMAIN)';
  } else {
    const mx = (Array.isArray(j.Answer) ? j.Answer : []).filter(a => a && a.type === 15);
    if (!mx.length) { lead.status = 'skipped_no_route'; lead.reason = 'no MX record for the domain'; }
    else if (mx.every(a => /^\s*0\s+\.?\s*$/.test(String(a.data || '')))) { lead.status = 'skipped_no_route'; lead.reason = 'null MX: the domain says it accepts no mail'; }
    else {
      lead.mx_ok = true;
      if (lead.email_source === 'guessed') { lead.email_confidence = 'guessed_mx_ok'; lead.reason = 'MX exists, mailbox NOT verified'; }
    }
  }
  out.push({ json: { lead } });
}
return out;
