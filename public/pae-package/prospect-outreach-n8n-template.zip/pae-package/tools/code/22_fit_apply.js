// Joins the model's fit score back to each company, by position. Low fit stops here (no contact credits spent).
const cfg = PAE.cfg();
const companies = $('2c. Companies: Normalize').all();
const results = $input.all();
const out = [];
for (let i = 0; i < companies.length; i++) {
  const c = JSON.parse(JSON.stringify(companies[i].json.company));
  const r = results[i] ? (results[i].json || {}) : { error: 'no result for this company' };
  const o = (r && typeof r.output === 'object' && r.output) ? r.output : null;
  let pass = false;
  c.fit_status = 'skipped_low_fit';
  if (r.error || !o) { c.fit_status = 'fit_failed'; c.fit_score = null; c.fit_reason = 'fit scoring failed: ' + PAE.errText(r.error || 'no structured output'); }
  else {
    c.fit_score = PAE.num(o.fit_score, 0, 1, 0);
    c.fit_reason = PAE.strip(o.reason).slice(0, 300);
    pass = c.fit_score >= cfg.min_confidence;
    if (!pass) c.fit_reason = 'below min_confidence ' + cfg.min_confidence + ': ' + c.fit_reason;
  }
  out.push({ json: { company: c, pass } });
}
return out;
