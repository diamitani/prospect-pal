// Usage: cd <folder with node_modules for n8n-nodes-base and @n8n/n8n-nodes-langchain> && node introspect.js
// Writes defs.json: parameter names, option values and versions of every node type the template uses.
const path=require('path');
const base='n8n-nodes-base/dist/nodes/';
const lc='@n8n/n8n-nodes-langchain/dist/nodes/';
const targets={
 'n8n-nodes-base.manualTrigger':base+'ManualTrigger/ManualTrigger.node.js',
 'n8n-nodes-base.webhook':base+'Webhook/Webhook.node.js',
 'n8n-nodes-base.set':base+'Set/Set.node.js',
 'n8n-nodes-base.code':base+'Code/Code.node.js',
 'n8n-nodes-base.if':base+'If/If.node.js',
 'n8n-nodes-base.switch':base+'Switch/Switch.node.js',
 'n8n-nodes-base.httpRequest':base+'HttpRequest/HttpRequest.node.js',
 'n8n-nodes-base.splitInBatches':base+'SplitInBatches/SplitInBatches.node.js',
 'n8n-nodes-base.merge':base+'Merge/Merge.node.js',
 'n8n-nodes-base.wait':base+'Wait/Wait.node.js',
 'n8n-nodes-base.emailSend':base+'EmailSend/EmailSend.node.js',
 'n8n-nodes-base.stickyNote':base+'StickyNote/StickyNote.node.js',
 'n8n-nodes-base.errorTrigger':base+'ErrorTrigger/ErrorTrigger.node.js',
 'n8n-nodes-base.noOp':base+'NoOp/NoOp.node.js',
 'n8n-nodes-base.respondToWebhook':base+'RespondToWebhook/RespondToWebhook.node.js',
 '@n8n/n8n-nodes-langchain.chainLlm':lc+'chains/ChainLLM/ChainLlm.node.js',
 '@n8n/n8n-nodes-langchain.lmChatAnthropic':lc+'llms/LMChatAnthropic/LmChatAnthropic.node.js',
 '@n8n/n8n-nodes-langchain.outputParserStructured':lc+'output_parser/OutputParserStructured/OutputParserStructured.node.js',
};
const out={};
for(const [type,p] of Object.entries(targets)){
  try{
    const mod=require(path.resolve('node_modules',p));
    const cls=Object.values(mod).find(v=>typeof v==='function');
    const inst=new cls();
    const versions={};
    if(inst.nodeVersions){ for(const [v,n] of Object.entries(inst.nodeVersions)) versions[v]=n.description; }
    else { const d=inst.description; const vs=Array.isArray(d.version)?d.version:[d.version]; for(const v of vs) versions[String(v)]=d; }
    out[type]={versions:Object.fromEntries(Object.entries(versions).map(([v,d])=>[v,{props:(d.properties||[]).map(x=>({name:x.name,type:x.type,default:x.default,options:(x.options||[]).map(o=>o.value!==undefined?o.value:o.name).slice(0,40)}))}])),
      latest:(inst.currentVersion||Math.max(...Object.keys(versions).map(Number)))};
    console.log(type,'latest',out[type].latest,'versions',Object.keys(versions).join(','));
  }catch(e){console.log('FAIL',type,e.message.split('\n')[0]);}
}
require('fs').writeFileSync('defs.json',JSON.stringify(out));
