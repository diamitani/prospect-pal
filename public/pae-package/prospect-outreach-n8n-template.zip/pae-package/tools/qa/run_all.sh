#!/bin/bash
# Runs every check. Needs python3, node, and (for the e2e steps) an n8n install: set N8N_BIN. Stops at the first failure.
set -e
cd "$(dirname "$0")/.."
echo "== regenerate workflows"; python3 generate_workflows.py
echo "== structure + parameter lint"; python3 qa/lint_workflows.py
echo "== lint self-test (planted defects must be caught)"; python3 qa/lint_selftest.py
echo "== Code-node behaviour tests"; node qa/code_tests.js
if [ -x "${N8N_BIN:-/home/claude/n8nrun/node_modules/.bin/n8n}" ]; then
  echo "== end-to-end on real n8n (mock servers, nothing external)"
  python3 test/e2e_assert.py
  python3 test/e2e_webhook.py
  python3 test/e2e_errorflow.py
else echo "== skipped e2e: n8n not found (set N8N_BIN)"; fi
echo "ALL CHECKS PASSED"
