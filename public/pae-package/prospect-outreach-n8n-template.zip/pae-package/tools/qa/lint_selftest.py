#!/usr/bin/env python3
"""Proves the lint can fail: plants one defect at a time in a temp copy and expects a BLOCK for each."""
import json, os, shutil, subprocess, sys, tempfile
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
def mutate(fn, wfname):
    d = tempfile.mkdtemp()
    os.makedirs(os.path.join(d, "tools", "qa")); os.makedirs(os.path.join(d, "workflows"))
    shutil.copy(os.path.join(ROOT, "tools", "qa", "defs.json"), os.path.join(d, "tools", "qa"))
    for f in os.listdir(os.path.join(ROOT, "workflows")):
        shutil.copy(os.path.join(ROOT, "workflows", f), os.path.join(d, "workflows"))
    p = os.path.join(d, "workflows", wfname)
    wf = json.load(open(p)); extra = fn(wf, d); json.dump(wf, open(p, "w"))
    r = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "qa", "lint_workflows.py"), d], capture_output=True, text=True)
    shutil.rmtree(d); return r.returncode, r.stdout
def node(wf, name): return next(n for n in wf["nodes"] if n["name"] == name)
cases = [
 ("reference to a node that does not exist", lambda wf, d: node(wf, "6e. Research: Verify")["parameters"].update(jsCode="const x = $('No Such Node').first();"), "pae-main.json"),
 ("unknown parameter name", lambda wf, d: node(wf, "Config")["parameters"].update(bogusParam=1), "pae-main.json"),
 ("typeVersion that is not installed", lambda wf, d: node(wf, "5b. Ready?").update(typeVersion=9), "pae-main.json"),
 ("webhook with no auth", lambda wf, d: node(wf, "Webhook")["parameters"].update(authentication="none"), "pae-main.json"),
 ("option value that does not exist", lambda wf, d: node(wf, "Webhook")["parameters"].update(httpMethod="YEET"), "pae-main.json"),
 ("secret planted in a Code node", lambda wf, d: node(wf, "Config")["parameters"]["assignments"]["assignments"][0].update(value="sk-" + "ant-api03-" + "A" * 28), "pae-main.json"),
 ("send node enabled by default", lambda wf, d: node(wf, "8d. Send Email (SMTP)").update(disabled=False), "pae-main.json"),
 ("dry_run default switched off", lambda wf, d: [a.update(value=False) for a in node(wf, "Config")["parameters"]["assignments"]["assignments"] if a["name"] == "dry_run"], "pae-main.json"),
 ("connection to a missing node", lambda wf, d: wf["connections"]["Config"]["main"][0].append({"node": "Ghost", "type": "main", "index": 0}), "pae-main.json"),
 ("orphan node", lambda wf, d: wf["nodes"].append({"parameters": {}, "id": "zz", "name": "Orphan", "type": "n8n-nodes-base.noOp", "typeVersion": 1, "position": [0, 0]}), "pae-main.json"),
 ("Code node with a syntax error", lambda wf, d: node(wf, "1a. Signals: Brief")["parameters"].update(jsCode="const = ;"), "pae-main.json"),
 ("Code node calling require", lambda wf, d: node(wf, "1a. Signals: Brief")["parameters"].update(jsCode="const fs = require('fs');"), "pae-main.json"),
 ("HTTP node with a hard-coded http URL", lambda wf, d: node(wf, "1b. Signals: Fetch (HTTP)")["parameters"].update(url="http://evil.example"), "pae-main.json"),
 ("pre-filled alert webhook", lambda wf, d: node(wf, "Alert Config")["parameters"]["assignments"]["assignments"][0].update(value="https://x.example/hook"), "pae-error-alert.json"),
]
bad = 0
for label, fn, wfn in cases:
    code, out = mutate(fn, wfn)
    ok = code != 0
    bad += (not ok)
    print(("caught   " if ok else "MISSED   ") + label)
print("\n%d/%d planted defects caught" % (len(cases) - bad, len(cases)))
sys.exit(1 if bad else 0)
