#!/usr/bin/env python3
"""Deterministic QA for the PAE package. No network, no model.

Runs: (1) structure lint, (2) parameter lint against the installed n8n node definitions (defs.json),
(3) deterministic security scan of the whole package tree.
Exit code 0 = no BLOCKING finding. Prints a findings table. Used by the Jev QA report.

Usage: python3 tools/qa/lint_workflows.py [package_root]
"""
import json
import os
import re
import subprocess
import sys
import tempfile

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
WF_DIR = os.path.join(ROOT, "workflows")
DEFS = json.load(open(os.path.join(ROOT, "tools", "qa", "defs.json")))
findings = []  # (severity, area, workflow, message)


def F(sev, area, wf, msg):
    findings.append((sev, area, wf, msg))


def walk_strings(o, path=""):
    if isinstance(o, str):
        yield path, o
    elif isinstance(o, dict):
        for k, v in o.items():
            yield from walk_strings(v, path + "." + str(k))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from walk_strings(v, path + "[" + str(i) + "]")


TRIGGERS = {"n8n-nodes-base.manualTrigger", "n8n-nodes-base.webhook", "n8n-nodes-base.errorTrigger"}
OUTPUT_COUNT = {"n8n-nodes-base.if": 2, "n8n-nodes-base.splitInBatches": 2, "n8n-nodes-base.merge": 1}


def structure_lint(name, wf):
    nodes = wf["nodes"]
    names = [n["name"] for n in nodes]
    ids = [n["id"] for n in nodes]
    if len(set(names)) != len(names):
        F("BLOCK", "structure", name, "duplicate node names")
    if len(set(ids)) != len(ids):
        F("BLOCK", "structure", name, "duplicate node ids")
    byname = {n["name"]: n for n in nodes}
    edges = []
    for src, kinds in wf["connections"].items():
        if src not in byname:
            F("BLOCK", "structure", name, "connection from missing node " + src)
            continue
        for kind, outs in kinds.items():
            for oi, targets in enumerate(outs):
                for t in targets:
                    if t["node"] not in byname:
                        F("BLOCK", "structure", name, "connection to missing node " + t["node"])
                        continue
                    edges.append((src, t["node"], kind, oi, t["index"]))
                    if kind == "main":
                        st = byname[src]["type"]
                        cap = OUTPUT_COUNT.get(st)
                        if st == "n8n-nodes-base.switch":
                            cap = len(byname[src]["parameters"]["rules"]["values"])
                        if cap is not None and oi >= cap:
                            F("BLOCK", "structure", name, "%s uses output %d but has %d" % (src, oi, cap))
                        if byname[t["node"]]["type"] == "n8n-nodes-base.merge" and t["index"] >= byname[t["node"]]["parameters"].get("numberInputs", 2):
                            F("BLOCK", "structure", name, "%s feeds Merge input %d beyond numberInputs" % (src, t["index"]))
    # reachability: forward over main edges from triggers; ai_* edges make the sub-node reachable when its parent is
    reach = {n["name"] for n in nodes if n["type"] in TRIGGERS}
    changed = True
    while changed:
        changed = False
        for s, t, kind, _, _ in edges:
            if kind == "main" and s in reach and t not in reach:
                reach.add(t); changed = True
            if kind.startswith("ai_") and t in reach and s not in reach:
                reach.add(s); changed = True
    for n in nodes:
        if n["type"] == "n8n-nodes-base.stickyNote":
            continue
        if n["name"] not in reach:
            F("BLOCK", "structure", name, "node not reachable from a trigger: " + n["name"])
    if not any(n["type"] in TRIGGERS for n in nodes):
        F("BLOCK", "structure", name, "no trigger node")
    # expression references and brace balance
    ref_re = re.compile(r"\$\(\s*['\"]([^'\"]+)['\"]\s*\)")
    ref2_re = re.compile(r"\$node\[\s*['\"]([^'\"]+)['\"]\s*\]")
    for n in nodes:
        for path, s in walk_strings(n["parameters"]):
            if s.startswith("=") and s.count("{{") != s.count("}}"):
                F("BLOCK", "structure", name, "unbalanced {{ }} in %s%s" % (n["name"], path))
            for m in ref_re.findall(s) + ref2_re.findall(s):
                if m not in byname:
                    F("BLOCK", "structure", name, "%s references missing node %s" % (n["name"], m))
    # Code node JavaScript parses
    for n in nodes:
        if n["type"] == "n8n-nodes-base.code":
            src = "async function __n8n($input, $, $json, $item, $node){\n" + n["parameters"]["jsCode"] + "\n}\n"
            with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False) as f:
                f.write(src)
                tmp = f.name
            r = subprocess.run(["node", "--check", tmp], capture_output=True, text=True)
            os.unlink(tmp)
            if r.returncode != 0:
                F("BLOCK", "structure", name, "Code node does not parse: %s: %s" % (n["name"], r.stderr.strip().splitlines()[-1][:160]))
    # connection type sanity
    for s, t, kind, _, _ in edges:
        if kind.startswith("ai_") and not byname[t]["type"].startswith("@n8n/n8n-nodes-langchain."):
            F("BLOCK", "structure", name, "ai connection into a non-AI node: " + t)
    return byname


def param_lint(name, wf):
    skipped = set()
    for n in wf["nodes"]:
        t = n["type"]
        if t not in DEFS:
            skipped.add(t)
            continue
        vers = DEFS[t]["versions"]
        v = str(n["typeVersion"])
        if v not in vers:
            F("BLOCK", "parameters", name, "%s: typeVersion %s not in installed versions %s" % (n["name"], v, ",".join(vers)))
            continue
        props = {}
        for p in vers[v]["props"]:
            props.setdefault(p["name"], []).append(p)
        for k, val in n["parameters"].items():
            if k not in props:
                F("BLOCK", "parameters", name, "%s: unknown parameter '%s' for %s v%s" % (n["name"], k, t.split(".")[-1], v))
                continue
            if isinstance(val, str) and not val.startswith("="):
                allowed = set()
                typed = False
                for p in props[k]:
                    if p["type"] == "options" and p.get("options"):
                        typed = True
                        allowed.update(str(o) for o in p["options"])
                if typed and val not in allowed:
                    F("BLOCK", "parameters", name, "%s: '%s' = '%s' not one of %s" % (n["name"], k, val, sorted(allowed)[:8]))
            if isinstance(val, bool) or isinstance(val, (int, float)):
                pass
    return skipped


def security_scan(wfs):
    # secrets anywhere in the package (workflows, code, docs, skills, prompts)
    pats = [("OpenAI/Anthropic style key", r"sk-(?:ant-|proj-)?[A-Za-z0-9_\-]{20,}"), ("Slack token", r"xox[abprs]-[A-Za-z0-9\-]{10,}"),
            ("AWS key id", r"AKIA[0-9A-Z]{16}"), ("private key block", r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
            ("bearer token literal", r"Bearer\s+[A-Za-z0-9\-_\.]{24,}"), ("Slack webhook URL", r"https://hooks\.slack\.com/services/[A-Za-z0-9/]+"),
            ("Discord webhook URL", r"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_\-]+")]
    for dp, _, fs in os.walk(ROOT):
        if "node_modules" in dp or dp.endswith("__pycache__"):
            continue
        for fn in fs:
            if fn.endswith((".zip", ".png", ".pdf", ".gif")) or fn == "defs.json":
                continue
            p = os.path.join(dp, fn)
            try:
                txt = open(p, errors="ignore").read()
            except Exception:
                continue
            for label, rx in pats:
                if re.search(rx, txt):
                    F("BLOCK", "secrets", os.path.relpath(p, ROOT), "possible " + label)
    for name, wf in wfs.items():
        for n in wf["nodes"]:
            t = n["type"]
            if t == "n8n-nodes-base.webhook" and n["parameters"].get("authentication", "none") == "none":
                F("BLOCK", "security", name, "webhook without authentication: " + n["name"])
            if t == "n8n-nodes-base.webhook" and n["parameters"].get("responseMode") != "responseNode":
                F("WARN", "security", name, "webhook does not answer early via Respond node: " + n["name"])
            for c in (n.get("credentials") or {}).values():
                if set(c.keys()) - {"id", "name"}:
                    F("BLOCK", "secrets", name, "credential with inline data in " + n["name"])
            if n.get("retryOnFail") and int(n.get("maxTries", 3)) > 3:
                F("BLOCK", "bounded", name, "retry count above 3 in " + n["name"])
            if t == "n8n-nodes-base.httpRequest":
                url = n["parameters"].get("url", "")
                if not url.startswith("=") and not url.startswith("https://"):
                    F("BLOCK", "security", name, "HTTP node with non-https literal URL: " + n["name"])
                if not url.startswith("="):
                    F("WARN", "security", name, "HTTP node URL is a literal, not from the validated Config: " + n["name"])
                elif "Validate Config" not in url and "$json.alert_url" not in url:
                    F("BLOCK", "security", name, "HTTP node URL does not come from the validated config: " + n["name"])
                if n["parameters"].get("options", {}).get("timeout") is None:
                    F("WARN", "bounded", name, "HTTP node without timeout: " + n["name"])
            if t == "n8n-nodes-base.code":
                js = n["parameters"]["jsCode"]
                for bad in [r"\brequire\s*\(", r"\bfetch\s*\(", r"\beval\s*\(", r"\bprocess\.", r"child_process", r"\$env\b", r"new Function", r"\bimport\s*\("]:
                    if re.search(bad, js):
                        F("BLOCK", "security", name, "Code node uses %s: %s" % (bad, n["name"]))
                for m in re.finditer(r"while\s*\(", js):
                    F("BLOCK", "bounded", name, "while loop in Code node " + n["name"])
        loops = [n for n in wf["nodes"] if n["type"] == "n8n-nodes-base.splitInBatches"]
        for n in loops:
            if not isinstance(n["parameters"].get("batchSize"), int):
                F("BLOCK", "bounded", name, "loop batchSize is not a fixed number")
    # safe defaults in the shipped Config
    main = wfs.get("pae-main.json")
    if main:
        cfg = next(n for n in main["nodes"] if n["name"] == "Config")
        vals = {a["name"]: a["value"] for a in cfg["parameters"]["assignments"]["assignments"]}
        want = {"dry_run": True, "outreach_mode": "log_only", "allow_guessed_sends": False, "allow_webhook_live_send": False,
                "allow_private_urls": False, "allow_links": False, "contacts_source": "provided", "start_mode": "from_icp"}
        for k, v in want.items():
            if vals.get(k) != v:
                F("BLOCK", "defaults", "pae-main.json", "unsafe default for %s: %r (expected %r)" % (k, vals.get(k), v))
        for n in main["nodes"]:
            if n["type"] == "n8n-nodes-base.emailSend" and not n.get("disabled"):
                F("BLOCK", "defaults", "pae-main.json", "send node ships enabled: " + n["name"])
        for k in ("signals_url", "companies_url", "contacts_url", "research_url", "sequence_api_url", "callback_url", "mailbox_from"):
            if vals.get(k):
                F("BLOCK", "defaults", "pae-main.json", "a URL/address is pre-filled in Config: " + k)
    err = wfs.get("pae-error-alert.json")
    if err:
        c = next(n for n in err["nodes"] if n["name"] == "Alert Config")
        v = {a["name"]: a["value"] for a in c["parameters"]["assignments"]["assignments"]}
        if v.get("alert_webhook_url"):
            F("BLOCK", "defaults", "pae-error-alert.json", "alert webhook URL is pre-filled")


def main():
    wfs = {}
    for fn in sorted(os.listdir(WF_DIR)):
        if fn.endswith(".json"):
            wfs[fn] = json.load(open(os.path.join(WF_DIR, fn)))
    skipped_all = set()
    counts = {}
    for fn, wf in wfs.items():
        structure_lint(fn, wf)
        skipped_all |= param_lint(fn, wf)
        counts[fn] = len([n for n in wf["nodes"] if n["type"] != "n8n-nodes-base.stickyNote"])
    security_scan(wfs)
    print("Workflows:", ", ".join("%s (%d nodes)" % (k, v) for k, v in counts.items()))
    print("Node types not introspected (checked by hand):", sorted(skipped_all) or "none")
    sev = {"BLOCK": 0, "WARN": 0}
    for s, a, w, m in findings:
        sev[s] += 1
        print("[%s] %-10s %-22s %s" % (s, a, w, m))
    print("\nstructure/parameter/security findings: BLOCK=%d WARN=%d" % (sev["BLOCK"], sev["WARN"]))
    sys.exit(1 if sev["BLOCK"] else 0)


if __name__ == "__main__":
    main()
