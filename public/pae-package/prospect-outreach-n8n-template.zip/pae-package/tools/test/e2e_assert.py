#!/usr/bin/env python3
"""Runs every scenario in a REAL n8n (n8n execute) against the mock server and asserts the outcome.
Needs: n8n installed (N8N_BIN in e2e_env.sh), python3, and port MOCK_PORT free. Starts and stops the mock itself."""
import collections, json, os, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
PORT = os.environ.get("MOCK_PORT", "9101")
LOG = "/tmp/pae-mock.log"

def run(s):
    r = subprocess.run(["bash", os.path.join(HERE, "run_scenario.sh"), s], capture_output=True, text=True, env=dict(os.environ, MOCK_PORT=PORT))
    raw = open("/tmp/%s.out" % s).read()
    calls = collections.Counter()
    for l in open(LOG):
        e = json.loads(l); calls[e["method"] + " " + e["path"].split("?")[0]] += 1
    d = None
    dec = json.JSONDecoder()
    pos = 0
    while True:
        pos = raw.find("\n{", pos) if pos else (0 if raw.startswith("{") else raw.find("\n{"))
        if pos < 0: break
        start = pos + (0 if raw.startswith("{") and pos == 0 else 1)
        try:
            cand, _ = dec.raw_decode(raw[start:])
            if isinstance(cand, dict) and ("data" in cand or "resultData" in cand): d = cand; break
        except Exception: pass
        pos = start + 1
    if d is None:
        msg = next((l for l in raw.splitlines() if "REPLACE ME" in l or l.startswith("Error")), raw.strip()[:300])
        return {"error": msg, "rows": {}, "summary": None, "calls": calls, "bodies": []}
    rd = d.get("data", {}).get("resultData", d.get("resultData", {}))
    runs = rd.get("runData", {})
    rows, summary = {}, None
    if "9a. Report: Rows" in runs:
        rows = {}
        for x in runs["9a. Report: Rows"][-1]["data"]["main"][0]:
            rows.setdefault(x["json"]["company"], []).append(x["json"])
        summary = runs["9b. Report: Summary"][-1]["data"]["main"][0][0]["json"]
    bodies = [json.loads(json.loads(l)["body"] or "{}") for l in open(LOG) if json.loads(l)["path"] == "/callback"]
    return {"error": (rd.get("error") or {}).get("message"), "rows": rows, "summary": summary, "calls": calls, "bodies": bodies}

def st(r, company, i=0): return r["rows"][company][i]["status"]
def reason(r, company, i=0): return r["rows"][company][i]["reason"]

CHECKS = []
def check(scn, label, fn): CHECKS.append((scn, label, fn))

check("smoke", "low fit stops before contacts and research", lambda r: st(r, "Lowfit Corp") == "skipped_low_fit")
check("smoke", "unparseable model output is reported as fit_failed", lambda r: st(r, "Badjson Co") == "fit_failed")
check("smoke", "good lead becomes a draft, nothing sent", lambda r: st(r, "Northwind Labs", 0) == "drafted" and r["summary"]["nothing_was_sent"] is True)
check("smoke", "hostile email is held for review with the right flags", lambda r: st(r, "Northwind Labs", 1) == "needs_review" and all(f in reason(r, "Northwind Labs", 1) for f in ("link_not_allowed", "banned_phrase", "exclamation_mark", "unverified_number")))
check("smoke", "no verified hook holds the lead", lambda r: st(r, "Nohook Inc") == "needs_review" and "no_verified_hook" in reason(r, "Nohook Inc"))
check("smoke", "fabricated quote dropped, real hook kept", lambda r: st(r, "Fabricate Ltd") == "drafted" and r["rows"]["Fabricate Ltd"][0]["hooks_dropped"] >= 1)
check("smoke", "no notes means no evidence means no email", lambda r: st(r, "NoNotes Co") == "needs_review" and "no_evidence" in reason(r, "NoNotes Co"))
check("smoke", "LLM calls match expectation (6 fit + 4 research + 3 email)", lambda r: r["calls"]["POST /v1/messages"] == 13)
check("smoke", "no outreach endpoint was touched", lambda r: not any(k.endswith("/sequence") for k in r["calls"]))
check("guess", "guessed email with MX ok is labelled guessed_mx_ok, not verified", lambda r: st(r, "Guess Co") == "drafted" and r["rows"]["Guess Co"][0]["email_confidence"] == "guessed_mx_ok")
check("guess", "NXDOMAIN and null MX are skipped", lambda r: st(r, "Nxdomain Co") == "skipped_no_route" and st(r, "Nullmx Co") == "skipped_no_route")
check("guess", "no domain means no guess", lambda r: st(r, "Nodomain Co") == "skipped_no_domain")
check("provider", "provider contact drafted; person without email skipped; empty company reported", lambda r: st(r, "Prov Co", 0) == "drafted" and st(r, "Prov Co", 1) == "skipped_no_email" and st(r, "Empty Co") == "skipped_no_contact")
check("provider", "one provider call per company", lambda r: r["calls"]["POST /contacts"] == 2)
check("http", "signals, companies and web research all fetched over HTTP", lambda r: st(r, "Http Co") == "drafted" and r["calls"]["GET /signals"] == 1 and r["calls"]["GET /companies"] == 1 and r["calls"]["POST /research"] == 1)
check("leads", "have_leads path skips steps 1 and 2 (no fit scoring)", lambda r: st(r, "Lead Co", 0) == "drafted" and st(r, "Lead Co", 1) == "skipped_no_email" and r["calls"]["POST /v1/messages"] == 2)
check("sequence_live", "live mode queues the provided-email lead", lambda r: st(r, "Seq Co") == "queued" and r["summary"]["nothing_was_sent"] is False)
check("sequence_live", "live mode still refuses a guessed address", lambda r: st(r, "Guessy Co") == "drafted" and "guess" in reason(r, "Guessy Co"))
check("sequence_live", "exactly one sequence call", lambda r: r["calls"]["POST /sequence"] == 1)
check("sequence_live_guess", "allow_guessed_sends lets the guess through, and the callback fires", lambda r: st(r, "Guess Co") == "queued" and len(r["bodies"]) == 1 and r["bodies"][0]["by_status"] == {"queued": 1})
check("sequence_reject", "a rejected push is reported as send_failed, not sent", lambda r: st(r, "Rej Co") == "send_failed" and "422" in reason(r, "Rej Co") and r["summary"]["nothing_was_sent"] is True)
check("mailbox_disabled", "disabled SMTP node cannot fake a send", lambda r: st(r, "Mail Co") == "send_unconfirmed")
check("nosig", "live mode without an opt-out line is held and nothing is pushed", lambda r: st(r, "Seq Co") == "needs_review" and "signature_missing_opt_out" in reason(r, "Seq Co") and "POST /sequence" not in r["calls"])
check("zero_ready", "when no lead is ready the run still finishes with a report", lambda r: r["summary"] is not None and r["summary"]["by_status"] == {"skipped_low_fit": 1})
check("callback", "callback receives the summary with rows", lambda r: len(r["bodies"]) == 1 and r["bodies"][0]["total_rows"] == 1 and len(r["bodies"][0]["rows"]) == 1)
check("placeholder", "REPLACE ME placeholders stop a manual run with a clear error", lambda r: r["error"] and "REPLACE ME" in r["error"])

if __name__ == "__main__":
    mock = subprocess.Popen([sys.executable, os.path.join(HERE, "mock_server.py"), PORT, LOG]); time.sleep(1)
    try:
        results, bad = {}, 0
        for scn in dict.fromkeys(c[0] for c in CHECKS):
            results[scn] = run(scn)
        for scn, label, fn in CHECKS:
            try: ok = bool(fn(results[scn]))
            except Exception as e: ok = False; label += " [error: %s]" % e
            bad += (not ok); print(("ok    " if ok else "FAIL  ") + scn.ljust(20) + label)
        print("\n%d checks, %d failed, %d scenarios run in real n8n" % (len(CHECKS), bad, len(results)))
        sys.exit(1 if bad else 0)
    finally:
        mock.terminate()
