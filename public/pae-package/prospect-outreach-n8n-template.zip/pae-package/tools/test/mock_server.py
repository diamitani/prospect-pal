#!/usr/bin/env python3
"""Local stand-in for every outside service the PAE template talks to. Test use only.

Serves: Anthropic /v1/messages, a DNS-over-HTTPS answer, and generic signal / company / contact /
research / sequence / callback endpoints. Every request is appended to the log file so a test can
prove what was (and was not) called. No real network, no real keys.
"""
import json
import os
import re
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 9101
LOG = sys.argv[2] if len(sys.argv) > 2 else "/tmp/pae-mock.log"
STREAM_SEEN = {"n": 0}


def text_of(content):
    if isinstance(content, str):
        return content
    return "\n".join(p.get("text", "") for p in content if isinstance(p, dict))


def wrap(text):
    """n8n's structured output parser (v1.2) tells the model to answer as {"output": {...}}. Real Claude follows that; so does the mock."""
    try:
        return json.dumps({"output": json.loads(text)})
    except Exception:
        return text


def anthropic_answer(req):
    return wrap(raw_answer(req))


def raw_answer(req):
    msgs = req.get("messages", [])
    prompt = "\n".join(text_of(m.get("content")) for m in msgs)
    system = req.get("system")
    system = text_of(system) if system else ""
    full = system + "\n" + prompt
    if "fit_score" in full:
        m = re.search(r'"name":"([^"]*)"', prompt)
        name = m.group(1) if m else ""
        if "badjson" in name.lower():
            return "this is not json at all"
        score = 0.2 if "lowfit" in name.lower() else 0.9
        return json.dumps({"fit_score": score, "reason": "Mock fit reason for " + name, "matched_signals": ["hiring a sales or revenue leader"]})
    if "evidence_quote" in full:
        m = re.search(r"<evidence>\n(.*?)\n</evidence>", prompt, re.S)
        ev = m.group(1) if m else ""
        if "NOHOOK" in ev:
            return json.dumps({"hooks": []})
        n = re.search(r"NOTES SUPPLIED BY THE USER: (.{40,}?)(?:\n\n|$)", ev, re.S)
        hooks = []
        if "FABRICATE" in ev:
            hooks.append({"fact": "They won an industry award last year.", "evidence_quote": "won the 2031 global industry award for excellence", "relevance": "shows momentum", "confidence": 0.95})
        if n:
            q = n.group(1)[:80]
            hooks.append({"fact": "Company note: " + q[:60], "evidence_quote": q, "relevance": "Matches what we sell.", "confidence": 0.8})
        hooks.append({"fact": "Low confidence hook", "evidence_quote": (n.group(1)[:50] if n else "x" * 20), "relevance": "weak", "confidence": 0.2})
        return json.dumps({"hooks": hooks})
    if "hook_used" in full:
        name = re.search(r"RECIPIENT: (\w+)", prompt)
        first = name.group(1) if name else "there"
        if first == "Hostile":
            return json.dumps({"subject": "RE: Amazing offer!", "body": "I hope this email finds you well! We grew revenue 4,200% for 300 clients. See https://evil.example/x now. [Name]", "hook_used": 1})
        if first == "BadEmailJson":
            return "not json"
        body = ("Your team's recent activity stood out to me, and it matches the problem we help with. "
                "We help revenue teams cut the manual research time before first outreach so reps spend it talking to buyers instead. "
                "If that is on your list this quarter, would a short note with how it works be useful? Happy to send it, or leave it if the timing is wrong.")
        return json.dumps({"subject": "Question about " + first + "'s team research", "body": body, "hook_used": 1})
    return "{}"


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n).decode("utf-8", "replace") if n else ""

    def _send(self, code, obj, ctype="application/json"):
        data = obj if isinstance(obj, (bytes, str)) else json.dumps(obj)
        data = data.encode() if isinstance(data, str) else data
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _record(self, body):
        with open(LOG, "a") as f:
            f.write(json.dumps({"method": self.command, "path": self.path, "key": self.headers.get("x-api-key", "")[:12], "body": body[:3000]}) + "\n")

    def do_GET(self):
        self._record("")
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/dns-query":
            name = (q.get("name") or [""])[0]
            if name.endswith("nxdomain.test"):
                return self._send(200, {"Status": 3})
            if name.endswith("nomx.test"):
                return self._send(200, {"Status": 0})
            if name.endswith("nullmx.test"):
                return self._send(200, {"Status": 0, "Answer": [{"name": name, "type": 15, "data": "0 ."}]})
            return self._send(200, {"Status": 0, "Answer": [{"name": name, "type": 15, "data": "10 mx." + name + "."}]})
        if u.path == "/signals":
            return self._send(200, [{"signal": "opened a second office"}, {"signal": "hiring a head of revenue"}])
        if u.path == "/companies":
            return self._send(200, [{"name": "Http Co", "domain": "http-co.test", "notes": "Http Co announced a new regional sales team and a revenue operations hire this month.",
                                     "people": [{"first_name": "Dana", "last_name": "Http", "title": "VP Sales", "email": "dana@http-co.test"}]}])
        self._send(404, {"error": "not found"})

    def do_POST(self):
        body = self._body()
        self._record(body)
        u = urlparse(self.path)
        if u.path == "/v1/messages":
            time.sleep(float(os.environ.get("MOCK_DELAY", "0")))
            req = json.loads(body or "{}")
            if req.get("stream"):
                STREAM_SEEN["n"] += 1
            txt = anthropic_answer(req)
            if req.get("stream"):
                ev = []
                ev.append("event: message_start\ndata: " + json.dumps({"type": "message_start", "message": {"id": "msg_mock", "type": "message", "role": "assistant", "model": req.get("model"), "content": [], "stop_reason": None, "usage": {"input_tokens": 10, "output_tokens": 1}}}))
                ev.append("event: content_block_start\ndata: " + json.dumps({"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}}))
                ev.append("event: content_block_delta\ndata: " + json.dumps({"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": txt}}))
                ev.append("event: content_block_stop\ndata: " + json.dumps({"type": "content_block_stop", "index": 0}))
                ev.append("event: message_delta\ndata: " + json.dumps({"type": "message_delta", "delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 20}}))
                ev.append("event: message_stop\ndata: " + json.dumps({"type": "message_stop"}))
                return self._send(200, "\n\n".join(ev) + "\n\n", "text/event-stream")
            return self._send(200, {"id": "msg_mock", "type": "message", "role": "assistant", "model": req.get("model"),
                                    "content": [{"type": "text", "text": txt}], "stop_reason": "end_turn", "stop_sequence": None,
                                    "usage": {"input_tokens": 10, "output_tokens": 20}})
        if u.path == "/contacts":
            d = json.loads(body or "{}")
            dom = d.get("domain", "")
            if dom.startswith("empty"):
                return self._send(200, [])
            return self._send(200, {"contacts": [{"first_name": "Pat", "last_name": "Provider", "title": "Head of Sales", "email": "pat@" + dom},
                                                {"full_name": "No Email", "title": "VP"}]})
        if u.path == "/research":
            d = json.loads(body or "{}")
            return self._send(200, {"results": [{"title": d.get("company", "") + " news", "snippet": d.get("company", "") + " opened a new regional hub and is hiring revenue operations managers this quarter."}]})
        if u.path == "/sequence":
            if "reject" in body:
                return self._send(422, {"error": "rejected"})
            return self._send(202, {"queued": True})
        if u.path == "/callback":
            return self._send(200, {"ok": True})
        if u.path == "/alert":
            return self._send(200, {"ok": True})
        self._send(404, {"error": "not found"})


if __name__ == "__main__":
    open(LOG, "w").close()
    ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
