#!/bin/bash
# usage: run_scenario.sh <scenario>   (needs the mock server running; see e2e_env.sh)
cd "$(dirname "$0")"; . ./e2e_env.sh
S=$1; ID="t$(echo $S | tr -d '_' | cut -c1-12)"; ID=$(printf '%-9s' "$ID" | tr ' ' 'x')
python3 make_test_workflow.py $S /tmp/t-$S.json $MOCK_PORT
$N8N_BIN import:workflow --input=/tmp/t-$S.json >/dev/null 2>&1
: > /tmp/pae-mock.log
timeout 300 $N8N_BIN execute --id=$ID --rawOutput > /tmp/$S.out 2>/tmp/$S.err
echo "exit=$? scenario=$S id=$ID"
