#!/usr/bin/env python3
"""Makes a TEST COPY of pae-main.json with Config values replaced, so a real n8n can run it against the mock server.
Usage: make_test_workflow.py <scenario> <out.json> [mock_port]
The shipped workflow is never edited."""
import json, sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(HERE, "..", "..", "workflows", "pae-main.json")
scenario, out = sys.argv[1], sys.argv[2]
port = sys.argv[3] if len(sys.argv) > 3 else "9101"
M = "http://127.0.0.1:" + port
base = {
    "icp": "Mid-size B2B software companies that sell to revenue teams.", "target_titles": "VP Sales; Head of Revenue Operations",
    "company_name": "Acme Test Co", "product_summary": "Acme Test Co sells research automation for sales teams.",
    "value_prop": "Cuts manual research time before first outreach.", "sender_first_name": "Sam",
    "signature": "Sam, Acme Test Co, 1 Test Street. Not relevant? Reply STOP and I will not write again.",
    "allow_private_urls": True, "dns_resolver_url": M + "/dns-query", "throttle_seconds": 0, "max_leads": 10,
}
good_notes = "Northwind Labs opened a new regional sales hub in Austin and is hiring three revenue operations managers this quarter."
def comp(name, domain, notes=good_notes, people=None):
    return {"name": name, "domain": domain, "industry": "Software", "size": "100-500", "notes": notes, "people": people or []}
def person(f, l, e, t="VP Sales"):
    return {"first_name": f, "last_name": l, "title": t, "email": e}
S = {}
S["smoke"] = dict(companies_json=json.dumps([
    comp("Northwind Labs", "northwind.test", people=[person("Riley", "Stone", "riley@northwind.test"), person("Hostile", "Writer", "h@northwind.test"), person("NoMail", "Person", "")]),
    comp("Lowfit Corp", "lowfit.test", people=[person("Lo", "Fit", "lo@lowfit.test")]),
    comp("Nohook Inc", "nohook.test", notes="NOHOOK this note has plenty of words but the research step will find nothing usable in it at all.", people=[person("No", "Hook", "no@nohook.test")]),
    comp("Fabricate Ltd", "fabricate.test", notes="FABRICATE Fabricate Ltd is a regional distributor with a small sales team and a new warehouse opening soon.", people=[person("Fab", "Ricate", "fab@fabricate.test")]),
    comp("Badjson Co", "badjson.test", people=[person("Bad", "Json", "bad@badjson.test")]),
    comp("NoNotes Co", "nonotes.test", notes="", people=[person("Non", "Otes", "non@nonotes.test")]),
]))
S["guess"] = dict(contacts_source="guess_syntax", companies_json=json.dumps([
    comp("Guess Co", "guess.test", people=[{"first_name": "Gina", "last_name": "Guess", "title": "VP Sales"}]),
    comp("Nxdomain Co", "nxdomain.test", people=[{"first_name": "Nora", "last_name": "Nx", "title": "VP Sales"}]),
    comp("Nullmx Co", "nullmx.test", people=[{"first_name": "Nell", "last_name": "Null", "title": "VP Sales"}]),
    comp("Nodomain Co", "", people=[{"first_name": "Dom", "last_name": "None", "title": "VP Sales"}]),
]))
S["provider"] = dict(contacts_source="provider_http", contacts_url=M + "/contacts", contacts_per_company=2, companies_json=json.dumps([
    comp("Prov Co", "prov.test"), comp("Empty Co", "empty.test")]))
S["http"] = dict(signals_source="http", signals_url=M + "/signals", companies_source="http", companies_url=M + "/companies",
                 research_source="http_search", research_url=M + "/research")
S["leads"] = dict(start_mode="have_leads", leads_json=json.dumps([
    {"company": "Lead Co", "domain": "lead.test", "first_name": "Lena", "last_name": "Lead", "title": "VP Sales", "email": "lena@lead.test", "notes": good_notes},
    {"company": "Lead Co", "domain": "lead.test", "first_name": "Mia", "last_name": "Missing", "title": "VP Sales", "email": "", "notes": good_notes}]))
S["sequence_live"] = dict(outreach_mode="sequence_api", sequence_api_url=M + "/sequence", dry_run=False, contacts_source="guess_syntax", companies_json=json.dumps([
    comp("Seq Co", "seq.test", people=[person("Sue", "Quence", "sue@seq.test")]),
    comp("Guessy Co", "guessy.test", people=[{"first_name": "Gus", "last_name": "Guess", "title": "VP Sales"}])]))
S["sequence_live_guess"] = dict(outreach_mode="sequence_api", sequence_api_url=M + "/sequence", dry_run=False, allow_guessed_sends=True,
    contacts_source="guess_syntax", callback_url=M + "/callback", companies_json=json.dumps([
    comp("Guess Co", "guess.test", people=[{"first_name": "Gina", "last_name": "Guess", "title": "VP Sales"}])]))
S["sequence_reject"] = dict(outreach_mode="sequence_api", sequence_api_url=M + "/sequence", dry_run=False, companies_json=json.dumps([
    comp("Rej Co", "rej.test", people=[person("Rex", "Reject", "reject@rej.test")])]))
S["mailbox_disabled"] = dict(outreach_mode="mailbox", mailbox_from="sam@example.com", dry_run=False, companies_json=json.dumps([
    comp("Mail Co", "mail.test", people=[person("Mel", "Mail", "mel@mail.test")])]))
S["nosig"] = dict(outreach_mode="sequence_api", sequence_api_url=M + "/sequence", dry_run=False, signature="Sam, Acme Test Co",
    companies_json=json.dumps([comp("Seq Co", "seq.test", people=[person("Sue", "Quence", "sue@seq.test")])]))
S["placeholder"] = dict(company_name="REPLACE ME: your company name")
S["zero_ready"] = dict(companies_json=json.dumps([comp("Lowfit Corp", "lowfit.test", people=[person("Lo", "Fit", "lo@lowfit.test")])]))
S["callback"] = dict(callback_url=M + "/callback", companies_json=json.dumps([comp("Cb Co", "cb.test", people=[person("Cy", "Back", "cy@cb.test")])]))
wf = json.load(open(src))
vals = dict(base); vals.update(S[scenario])
for n in wf["nodes"]:
    if n["name"] == "Config":
        for a in n["parameters"]["assignments"]["assignments"]:
            if a["name"] in vals:
                a["value"] = vals[a["name"]]
    if n["name"] == "Webhook":
        pass
wf["name"] = "PAE TEST " + scenario
wf["id"] = "t" + scenario.replace("_", "")[:12].ljust(8, "x")
json.dump(wf, open(out, "w"), indent=1)
