#!/usr/bin/env python3
"""Real-n8n test of the webhook entry: auth, validation, early 202 (measured), overrides, callback. Starts n8n + the mock."""
import json, os, subprocess, sys, time, urllib.request, urllib.error
HERE = os.path.dirname(os.path.abspath(__file__))
import shutil, tempfile
HOME = tempfile.mkdtemp(prefix="pae-n8n-wh-")  # fresh n8n database: webhook paths cannot collide with earlier tests
N8N = os.environ.get("N8N_BIN", "/home/claude/n8nrun/node_modules/.bin/n8n")
env = dict(os.environ, N8N_USER_FOLDER=HOME, N8N_DIAGNOSTICS_ENABLED="false", N8N_PORT="5688", N8N_LISTEN_ADDRESS="127.0.0.1")
LOG = "/tmp/pae-mock.log"
subprocess.run([sys.executable, os.path.join(HERE, "make_test_workflow.py"), "callback", "/tmp/t-wh.json"], check=True)
wf = json.load(open("/tmp/t-wh.json")); wf["id"] = "twebhooktst"
json.dump(wf, open("/tmp/t-wh.json", "w"))
subprocess.run([N8N, "import:credentials", "--input=" + os.path.join(HERE, "creds.json")], env=env, capture_output=True)
subprocess.run([N8N, "import:workflow", "--input=/tmp/t-wh.json"], env=env, capture_output=True)
subprocess.run([N8N, "publish:workflow", "--id=twebhooktst"], env=env, capture_output=True)
srv = subprocess.Popen([N8N, "start"], env=env, stdout=open("/tmp/n8n-wh.log", "w"), stderr=subprocess.STDOUT)
mock = subprocess.Popen([sys.executable, os.path.join(HERE, "mock_server.py"), "9101", LOG], env=dict(os.environ, MOCK_DELAY="1.5"))
URL = "http://127.0.0.1:5688/webhook/pae-run"
def post(body, key="test-key-123"):
    h = {"Content-Type": "application/json"}
    if key: h["X-PAE-Key"] = key
    req = urllib.request.Request(URL, data=json.dumps(body).encode(), method="POST", headers=h)
    t = time.time()
    try:
        r = urllib.request.urlopen(req, timeout=60); return r.status, json.loads(r.read() or b"{}"), time.time() - t
    except urllib.error.HTTPError as e:
        try: b = json.loads(e.read() or b"{}")
        except Exception: b = {}
        return e.code, b, time.time() - t
res = []
def chk(label, ok): res.append(ok); print(("ok    " if ok else "FAIL  ") + label)
try:
    for _ in range(60):
        time.sleep(2)
        try: urllib.request.urlopen("http://127.0.0.1:5688/healthz", timeout=2); break
        except Exception: pass
    time.sleep(4)
    chk("no key -> 403", post({}, key=None)[0] == 403)
    chk("wrong key -> 403", post({}, key="nope")[0] == 403)
    c, b, _ = post({"contacts_source": "hack"}); chk("bad enum -> 400 with reason", c == 400 and "must be one of" in b.get("error", ""))
    c, b, _ = post({"callback_url": "http://127.0.0.1:9101/callback"}); chk("private callback override -> 400", c == 400)
    open(LOG, "w").close()
    c, b, dt = post({"max_leads": 1, "dry_run": False, "bogus": 1, "companies_url": "https://evil.example"})
    chk("good call -> 202 with run_id", c == 202 and b.get("status") == "accepted" and b.get("run_id", "").startswith("pae-"))
    chk("202 returned in < 3 s while the run needs > 4 s (early response)", dt < 3.0)
    chk("overrides: unknown/URL ignored, dry_run stays on", set(b.get("warnings", [])) == {"ignored_override:bogus", "ignored_override:companies_url", "webhook_cannot_turn_dry_run_off"})
    got = None
    for _ in range(30):
        time.sleep(1)
        cbs = [json.loads(l) for l in open(LOG) if '"/callback"' in l]
        if cbs: got = json.loads(cbs[0]["body"]); break
    chk("callback arrives later with the summary", bool(got) and got["dry_run"] is True and got["nothing_was_sent"] is True and got["total_rows"] == 1)
    chk("run took longer than the 202 (callback after response)", bool(got))
finally:
    srv.terminate(); mock.terminate()
print("\n%d checks, %d failed" % (len(res), res.count(False)))
sys.exit(0 if all(res) else 1)
