# source me. Isolated n8n home so tests never touch a real instance.
export N8N_USER_FOLDER=${N8N_USER_FOLDER:-/home/claude/n8n-home}
export N8N_DIAGNOSTICS_ENABLED=false N8N_VERSION_NOTIFICATIONS_ENABLED=false N8N_PERSONALIZATION_ENABLED=false
export N8N_BIN=${N8N_BIN:-/home/claude/n8nrun/node_modules/.bin/n8n}
export MOCK_PORT=${MOCK_PORT:-9101}
