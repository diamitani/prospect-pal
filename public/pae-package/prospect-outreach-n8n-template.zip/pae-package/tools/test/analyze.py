#!/usr/bin/env python3
"""Reads the output of `n8n execute --rawOutput` and prints the report rows plus the mock-server request log."""
import json, sys, collections
name = sys.argv[1]
raw = open("/tmp/%s.out" % name).read()
i = raw.index("{")
d = json.loads(raw[i:])
rd = d.get("data", {}).get("resultData", d.get("resultData", {}))
run = rd["runData"]
print("status:", d.get("status"), "| error:", (rd.get("error") or {}).get("message"))
def items(node, r=-1, out=0):
    runs = run.get(node)
    if not runs: return None
    m = runs[r]["data"]["main"]
    return [x["json"] for x in (m[out] or [])] if len(m) > out and m[out] is not None else []
rows = items("9a. Report: Rows")
if rows is None:
    print("report did not run. nodes executed:", len(run)); sys.exit(0)
for r in rows:
    print("%-8s %-22s %-18s %-26s %-18s %s" % (r["lead_id"], r["status"], r["company"][:18], (r["email"] or "-")[:26], r["email_confidence"], r["reason"][:110]))
s = items("9b. Report: Summary")[0]
print("by_status:", s["by_status"], "| nothing_was_sent:", s["nothing_was_sent"], "| warnings:", s["warnings"])
counts = collections.Counter()
for l in open("/tmp/pae-mock.log"):
    e = json.loads(l); counts[e["method"] + " " + e["path"].split("?")[0]] += 1
print("mock calls:", dict(counts))
if len(sys.argv) > 2:
    for r in rows:
        if r["body"]:
            print("---", r["lead_id"], r["subject"], "\n", r["body"], "\n hook:", r["hook"], "| quote:", r["hook_quote"][:60])
