#!/usr/bin/env python3
"""Real-n8n test of the error workflow: a production (webhook) run fails on purpose and the alert must reach the mock endpoint,
with no lead data in it. Needs n8n + the mock server, same as e2e_assert.py."""
import json, os, subprocess, sys, time, urllib.request
HERE = os.path.dirname(os.path.abspath(__file__))
import shutil, tempfile
HOME = tempfile.mkdtemp(prefix="pae-n8n-ef-")  # fresh n8n database: webhook paths cannot collide with earlier tests
env = dict(os.environ); env_sh = open(os.path.join(HERE, "e2e_env.sh")).read()
N8N = os.environ.get("N8N_BIN", "/home/claude/n8nrun/node_modules/.bin/n8n")
env.update(N8N_USER_FOLDER=HOME, N8N_DIAGNOSTICS_ENABLED="false", N8N_PORT="5689", N8N_LISTEN_ADDRESS="127.0.0.1")
LOG = "/tmp/pae-mock.log"
subprocess.run([sys.executable, os.path.join(HERE, "make_test_workflow.py"), "callback", "/tmp/t-ef.json"], check=True)
main = json.load(open("/tmp/t-ef.json")); main["id"] = "terrormain"
for n in main["nodes"]:
    if n["name"] == "Config":
        for a in n["parameters"]["assignments"]["assignments"]:
            if a["name"] == "companies_source": a["value"] = "http"
            if a["name"] == "companies_url": a["value"] = "http://127.0.0.1:9101/missing"
            if a["name"] == "callback_url": a["value"] = ""
main["settings"]["errorWorkflow"] = "terrorflow"
err = json.load(open(os.path.join(HERE, "..", "..", "workflows", "pae-error-alert.json"))); err["id"] = "terrorflow"; err["name"] = "PAE TEST error alert"
for n in err["nodes"]:
    if n["name"] == "Alert Config":
        for a in n["parameters"]["assignments"]["assignments"]:
            if a["name"] == "alert_webhook_url": a["value"] = "http://127.0.0.1:9101/alert"
            if a["name"] == "allow_private_urls": a["value"] = True
json.dump(main, open("/tmp/t-ef-main.json", "w")); json.dump(err, open("/tmp/t-ef-err.json", "w"))
subprocess.run([N8N, "import:credentials", "--input=" + os.path.join(HERE, "creds.json")], env=env, capture_output=True)
for f in ("/tmp/t-ef-err.json", "/tmp/t-ef-main.json"):
    subprocess.run([N8N, "import:workflow", "--input=" + f], env=env, capture_output=True)
for i in ("terrorflow", "terrormain"):
    subprocess.run([N8N, "publish:workflow", "--id=" + i], env=env, capture_output=True)
srv = subprocess.Popen([N8N, "start"], env=env, stdout=open("/tmp/n8n-ef.log", "w"), stderr=subprocess.STDOUT)
mock = subprocess.Popen([sys.executable, os.path.join(HERE, "mock_server.py"), "9101", LOG]); ok = False
try:
    for _ in range(60):
        time.sleep(2)
        try: urllib.request.urlopen("http://127.0.0.1:5689/healthz", timeout=2); break
        except Exception: pass
    time.sleep(4)
    req = urllib.request.Request("http://127.0.0.1:5689/webhook/pae-run", data=b"{}", method="POST", headers={"X-PAE-Key": "test-key-123", "Content-Type": "application/json"})
    print("webhook answered:", urllib.request.urlopen(req, timeout=20).status)
    for _ in range(20):
        time.sleep(1.5)
        alerts = [json.loads(l) for l in open(LOG) if '"/alert"' in l]
        if alerts: break
    if alerts:
        body = json.loads(alerts[0]["body"])
        print("alert received:\n  " + body["text"].replace("\n", "\n  "))
        ok = "Company source failed" in body["text"] and "Example Co" not in body["text"] and "alex@example.com" not in body["text"] and "@" not in body["text"].replace("Execution", "")
    else: print("no alert reached the endpoint")
finally:
    srv.terminate(); mock.terminate()
print("ERROR-WORKFLOW TEST:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
