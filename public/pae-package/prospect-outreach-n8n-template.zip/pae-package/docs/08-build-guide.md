# 08 - Build guide

How to rebuild or change the workflows. Checkboxes are for you to tick. Each subtask has a "done when".

## Phase 1 - Set up the tools [N]
- [ ] Python 3, Node 18+, and an n8n install in a scratch folder (`npm install n8n`).
  - Done when: `python3 --version`, `node --version` and `n8n --version` all answer.
- [ ] Set `N8N_BIN` to the n8n binary (optional; only the end-to-end tests need it).

## Phase 2 - Understand the generator [N]
- [ ] Read `tools/generate_workflows.py`: it builds the two JSON files in `workflows/`.
- [ ] Read `tools/code/*.js`: the text of every Code node (`00_helpers.js` is prepended to each).
  - Done when: you can say which file holds step 5's email checks (`14_email_qa.js`).

## Phase 3 - Make a change [A]
- [ ] Edit a Code file or the generator. Add new options as new Config rows, default off.
- [ ] Regenerate: `python3 tools/generate_workflows.py`.
  - Done when: `workflows/*.json` changed and no error printed.

## Phase 4 - Test [N]
- [ ] Run everything: `tools/qa/run_all.sh`.
  - Done when: it ends with `ALL CHECKS PASSED`.
- [ ] For a new rule, add a test to `tools/qa/code_tests.js` first, watch it fail, then fix the code.
- [ ] For a new path through the workflow, add a scenario to `tools/test/make_test_workflow.py` and checks to `tools/test/e2e_assert.py`.

## Phase 5 - Deploy [P]
- [ ] Follow `prompts/01-setup-prompt.md` on a non-production n8n.
- [ ] Deliberately break something (a bad company URL) and confirm the alert arrives without lead data.

## Phase 6 - Make it yours [O]
- [ ] Follow `prompts/03-make-it-yours.md`.

## Exact commands used by the checks
`python3 tools/qa/lint_workflows.py`, `python3 tools/qa/lint_selftest.py`, `node tools/qa/code_tests.js`, `python3 tools/test/e2e_assert.py`, `python3 tools/test/e2e_webhook.py`, `python3 tools/test/e2e_errorflow.py`.
