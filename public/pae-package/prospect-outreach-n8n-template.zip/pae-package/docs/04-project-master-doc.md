# 04 - Project master doc: Prospect Outreach (Prospect Pal) n8n template

Created by Patrick Diamitani, Diamitani Industries, for SalesGency. Part of the "Salesgency Agents" project (Prospect Pal, the prospect automation engine).

1. **Overview.** See `00-intent-brief.md`.
2. **Goals and KPIs.** See `03-kpi-tracking.md`.
3. **KPI reporting framework.** Run summary by callback to the owner's sheet, CRM or chat; weekly review of reply, bounce and opt-out numbers.
4. **Features (NPAO and 4Ds).**
   - PreD: confirm ICP, tools, rules. D1 Design: this package's docs. D2 Develop: generator and Code nodes. D3 Deploy: owner imports and links credentials. D4 Debug: dry runs, deliberate-failure test, report review.
   - N: safe defaults, validation, error alert. A: contact and research tool hooks, webhook. P: live sending behind limits. O: user's own skills and tools merged in.
5. **End users.** A beginner GTM operator or founder; their n8n engineer (human or AI).
6. **Tech stack and key sheet.** n8n 2.35.7 (tested), Anthropic API (`claude-sonnet-5-5`), DNS-over-HTTPS for MX checks, the user's contact, research, sequencing and SMTP services. Secrets live only as n8n credentials: `PAE Anthropic`, `PAE Webhook Key`, `PAE SMTP`. Values are never in the files.
7. **Build plan.** `08-build-guide.md`.
8. **Deployment plan.** Import alert workflow, import main workflow, create credentials, link error workflow, fill Config, dry run, then optional webhook, then optional live sending.
9. **Testing plan.** `10-qa-plan.md` and `QA-REPORT-*.md`.
10. **Tools and scripts.** `tools/generate_workflows.py`, `tools/code/*.js`, `tools/qa/*`, `tools/test/*`, `tools/qa/run_all.sh`.
11. **Documentation needed.** README, workflow overview, diagrams, overview page, skills, prompts.
12. **Next steps.** Owner runs Prompt 1 on a non-production n8n; connects a contact tool; tests one real send to their own inbox.
13. **Collaborators.** Owner, owner's n8n engineer, the user's AI assistant.
14. **PRD.** `01-prd.md`.

Roadmap ideas not built here: overview video, GTM tech-stack list, a Make.com version, a Vercel-hosted master agent.
