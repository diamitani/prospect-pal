# 10 - QA plan (written before the build, Jev format)

## Threat surface
Public webhook; outbound callbacks and fetched URLs (SSRF); secrets and credentials; unbounded loops and retries; prompt injection from company notes, fetched pages or webhook text; sending to wrong or guessed addresses; cost per run; alert leaking lead data.

## Claims the package will make (each must trace to a run)
1. Both workflows pass structure and parameter lint against installed n8n node definitions.
2. No secret or key appears anywhere in the package.
3. With default settings nothing is sent.
4. A guessed address is never sent unless allowed.
5. The webhook rejects bad keys and bad bodies, replies 202 early, and cannot enable live sending by default.
6. A failing run raises an alert with no lead data.
7. A disabled send node cannot produce a `sent` status.

## Deterministic checks
Secret scan of the whole tree; structure lint; parameter lint; planted-defect self-test of the linter; Code-node behaviour tests with hostile inputs; end-to-end runs on a real n8n against mock servers; webhook tests; error-workflow test.

## Verdict rules
BLOCK: any secret, one confirmed high-severity finding, or three or more confirmed findings. WARN: confirmed non-blocking findings. PASS: none. UNADJUDICATED: the independent review step could not run.
