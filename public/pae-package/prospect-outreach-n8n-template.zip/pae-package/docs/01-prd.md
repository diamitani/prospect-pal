# 01 - PRD

## Problem
Prospecting takes hours of manual research. Quick automation tends to send unverified claims and guessed emails, which hurts reputation and trust.

## Solution
An n8n template with a deterministic backbone and three narrow AI steps, safe defaults, and an honest report.

## In scope
- 6-step pipeline, manual and webhook start, error alert workflow.
- Three contact sources, two research sources, three outreach modes.
- Eight skills and four prompts.
- Automated checks and a QA report.

## Out of scope
- Hosting n8n, buying data, building a reply-handling or meeting-booking flow.
- A built-in contact database or email verifier (the user brings one).
- Legal advice on cold-email law.
- Import or activation inside the owner's n8n (the owner does this).

## Success criteria
1. Imports into n8n 2.35.7 and completes a dry run from the default settings after the `REPLACE ME` rows are filled.
2. No email is sent with default settings.
3. Every fact in an email traces to supplied evidence.
4. A failed run produces an alert with no lead data.
5. A beginner can follow the prompts without reading JSON.

## Non-functional requirements
- **Latency:** webhook replies `202` within seconds (tested under 3 s while the run takes longer).
- **Volume:** default 10 leads per run, up to the user's settings; throttle between sends.
- **Security:** header-key auth, validation, https-only URLs, private-host block, no secrets in files.
- **Cost:** three model calls per lead at most (fit per company, research and email per lead). Actual cost depends on the user's Anthropic plan and was not measured.

## Risks
| Risk | Mitigation |
|---|---|
| Emails sent to guessed addresses | Blocked by default, labelled |
| Invented facts | Evidence verifier drops unbacked hooks |
| Prompt injection from scraped text | Evidence is marked as untrusted; model has no tools; code decides actions |
| Sending abuse via webhook | Webhook cannot disable dry run by default |
| Node versions differ on the user's n8n | Versions pinned and documented; re-check on other versions |
| Cold email law differs by country | Signature must carry opt-out line; user responsible for compliance |
