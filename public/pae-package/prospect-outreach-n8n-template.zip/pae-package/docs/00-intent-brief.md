# 00 - Intent brief

**Status:** confirmed by the owner's request ("turn this into a working n8n template that anyone can install"). Interpretation stated in the README.

A downloadable n8n workflow, built from Patrick Diamitani's 6-step Prospect Outreach process (Signals/ICP, Companies, Contacts, Research, Email personalisation, Outreach), that anyone can install with a setup prompt. It turns an ideal-customer description and a company list into researched, quality-checked cold emails, drafting by default and sending only when the owner switches it on. It ships with companion skills (n8n engineer, prospect outreach, one per step) and prompts that ask the user's own AI and n8n engineer to combine it with their own skills and tools.

**Trigger:** manual run or secured webhook. **Outcome:** a report of every lead and a draft email for each lead that passed every check.
