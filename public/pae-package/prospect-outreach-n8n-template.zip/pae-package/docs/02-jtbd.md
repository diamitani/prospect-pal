# 02 - Jobs to be done

## Overview
When I want new customers but have little time, I want researched, honest first emails drafted for the right people, so I can spend my time on replies.

## Jobs and steps (NPAO: N Necessity, A Accelerator, P Pivot, O Optimisation)

| Job | Step | NPAO |
|---|---|---|
| Install safely | Create credentials, import both workflows, link error workflow | N |
| Say who I sell to | Fill ICP, titles, signals, product, value, signature | N |
| Get a safe first result | Dry run with 3 leads, read the report | N |
| Get real contacts | Connect a contact tool or supply people | A |
| Get fresh facts | Add company notes or a research tool | A |
| Send for real | Enable mailbox or sequencer with limits and opt-out | P |
| Run from other apps | Use the secured webhook and callback | P |
| Make it mine | Combine with own skills and tools (Prompt 3) | O |

## Deliverables
Two workflow files, eight skills, four prompts, docs, diagrams, overview page, QA report, test tools.
