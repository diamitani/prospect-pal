# 03 - KPI tracking

**North-star outcome:** qualified conversations started per week from outreach this workflow drafted or sent. Targets below are blank on purpose: the template has no baseline data. Fill them from your own numbers.

## KPI tree
| KPI | Baseline | Target | Source | Cadence |
|---|---|---|---|---|
| Leads processed per run | (yours) | (yours) | run summary | per run |
| Share of leads reaching `ready`/`drafted` | (yours) | (yours) | report rows | per run |
| Hooks dropped by the verifier | (yours) | track, do not minimise | report `hooks_dropped` | per run |
| Emails sent or queued | (yours) | within `max_sends_per_run` | report | per run |
| Reply rate, positive reply rate | (yours) | (yours) | your mailbox or sequencer | weekly |
| Bounce rate | (yours) | keep low; pause if rising | your mailbox or sequencer | weekly |
| Opt-outs and complaints | (yours) | zero tolerance for ignoring them | your mailbox or sequencer | weekly |
| Meetings booked | (yours) | (yours) | your calendar or CRM | weekly |

## Execution metrics (n8n)
Runs, failures, time per run, model cost per run. Read from n8n executions and your Anthropic usage page. Not measured in this package.

## Reporting and ownership
Send the `callback_url` summary to a sheet, CRM or chat channel the owner reads. **Profit and loss owner: the template owner (the person who installs it).** Their own sales numbers are not in this package.
